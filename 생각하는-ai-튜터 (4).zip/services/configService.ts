import { localGoogleSheetLoggerUrl } from './apiKey';

/**
 * 설정을 가져오는 서비스입니다.
 * 이 앱은 이제 services/apiKey.ts 파일에 정의된 로컬 설정만 사용합니다.
 */
export const configService = {
    /**
     * 구글 시트 웹 앱 로거 URL을 가져옵니다. apiKey.ts에서 직접 가져옵니다.
     * @returns {Promise<string | null>} URL을 찾으면 반환하고, 아니면 null을 반환합니다.
     */
    async getGoogleSheetLoggerUrl(): Promise<string | null> {
        if (typeof localGoogleSheetLoggerUrl === 'string' && localGoogleSheetLoggerUrl.trim() !== '') {
            console.log("정보: 로컬 구글 시트 로거 URL을 사용합니다.");
            return localGoogleSheetLoggerUrl;
        }
        console.warn("경고: services/apiKey.ts 파일에 구글 시트 로거 URL이 설정되지 않았습니다. 로그가 콘솔에만 기록됩니다.");
        return null;
    }
};