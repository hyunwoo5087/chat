import { configService } from './configService';
import type { AnalyticsService, InteractionLog, JournalLog } from '../types';

let sheetLoggerUrl: string | null | undefined = undefined; // undefined: 아직 가져오지 않음, null: 가져왔지만 찾을 수 없음

/**
 * 설정된 구글 시트 웹 앱으로 로그 항목을 전송합니다.
 * @param payload 로깅할 데이터.
 */
async function sendToGoogleSheet(payload: Record<string, any>) {
    // URL을 한 번만 가져와서 캐시합니다.
    if (sheetLoggerUrl === undefined) {
        sheetLoggerUrl = await configService.getGoogleSheetLoggerUrl();
    }

    if (!sheetLoggerUrl) {
        console.warn("구글 시트 로거 URL이 설정되지 않았습니다. 대신 콘솔에 로깅합니다.", payload);
        return;
    }

    try {
        await fetch(sheetLoggerUrl, {
            method: 'POST',
            mode: 'no-cors', // 브라우저에서 호출될 때 구글 앱스 스크립트 웹 앱은 종종 이 모드가 필요합니다.
            headers: {
                'Content-Type': 'application/json',
            },
            // 본문은 문자열이어야 하므로, 앱스 스크립트가 올바르게 파싱할 수 있도록 JSON을 다른 문자열로 감쌉니다.
            body: JSON.stringify(payload),
        });
        
        // 'no-cors' 모드는 응답을 확인할 수 없으므로, 성공적으로 작동했다고 가정합니다.
        console.log("📊 로그가 구글 시트로 전송되었습니다.", payload.logType);

    } catch (error) {
        console.error("구글 시트로 로그 전송 중 오류 발생:", error);
        console.log("실패한 페이로드:", payload);
    }
}


/**
 * 사용자 상호작용 및 기타 분석 이벤트를 로깅하기 위한 서비스입니다.
 * 이 버전은 설정된 경우 구글 시트 웹 앱으로 데이터를 전송합니다.
 */
export const analyticsService: AnalyticsService = {
    async logInteraction(log: InteractionLog) {
        const payload = {
            logType: 'interaction',
            timestamp: log.timestamp,
            sessionId: log.sessionId,
            school: log.studentData.school,
            grade: log.studentData.grade,
            class: log.studentData.class,
            student_number: log.studentData.studentNumber ?? 'N/A', // 학생 번호
            avatar: log.studentData.avatar.name,
            turn_number: log.turnNumber ?? 'N/A',         // [추가] 대화 순번
            hint_used: log.hintUsed ? 'Y' : 'N',          // [추가] 힌트 사용 여부
            response_time_ms: log.responseTimeMs ?? 'N/A', // [추가] AI 응답 소요 시간(ms)
            userMessage: log.userMessage,
            modelResponse: log.modelResponse.content.replace(/\n/g, ' '),
            question_dok_level: log.modelResponse.analysisData?.question_dok_level ?? 'N/A',
            answer_dok_level: log.modelResponse.analysisData?.answer_dok_level ?? 'N/A',
            dok_level: log.modelResponse.analysisData?.answer_dok_level ?? log.modelResponse.analysisData?.dok_level ?? 'N/A',
            dok_reasoning: log.modelResponse.analysisData?.dok_reasoning ?? 'N/A',
            answer_quality_feedback: log.modelResponse.analysisData?.answer_quality_feedback ?? 'N/A',
            keris_major: log.modelResponse.analysisData?.keris_major ?? 'N/A',
            keris_sub: log.modelResponse.analysisData?.keris_sub ?? 'N/A',
        };
        await sendToGoogleSheet(payload);
    },

    async logJournal(log: JournalLog) {
        const payload = {
            logType: 'journal',
            timestamp: log.timestamp,
            sessionId: log.sessionId,
            school: log.studentData.school,
            grade: log.studentData.grade,
            class: log.studentData.class,
            student_number: log.studentData.studentNumber ?? 'N/A',
            avatar: log.studentData.avatar.name,
            learned: log.journalEntry.learned.replace(/\n/g, ' '), // 줄바꿈 문자 변경
            pledge: log.journalEntry.pledge.replace(/\n/g, ' '),   // 줄바꿈 문자 변경
        };
        await sendToGoogleSheet(payload);
    },
};