/**
 * 로컬 API 키 및 설정 파일
 * --------------------------
 * 이 파일은 앱의 모든 설정을 관리하는 유일한 장소입니다.
 * 
 * 중요: API 키 관리 방식 변경
 * 보안 강화를 위해, Gemini API 키는 더 이상 이 파일에서 관리하지 않습니다.
 * 대신, 앱이 배포되는 환경의 '환경 변수'를 통해 안전하게 주입됩니다.
 * 로컬 개발 시에는 시스템에 환경 변수(예: process.env.API_KEY)를 설정해야 합니다.
 */

/**
 * 로컬 구글 시트 로거 URL
 * --------------------------
 * 데이터 로깅을 활성화하려면 이 값을 설정하세요.
 * 구글 앱스 스크립트로 배포한 웹 앱 URL을 여기에 직접 입력하면 됩니다.
 * 이 값이 비어 있으면 로그는 브라우저 콘솔에만 표시됩니다.
 * 
 * 예시:
 * export const localGoogleSheetLoggerUrl = 'https://script.google.com/macros/s/AKfycb.../exec';
 */
export const localGoogleSheetLoggerUrl = 'https://script.google.com/macros/s/AKfycbwtkRTBbh6c2faVRRUzfy0HdMlDM1GYRZum3z58SbPQn-52Tz_ifpmR2jNa1e_WdKO_/exec';