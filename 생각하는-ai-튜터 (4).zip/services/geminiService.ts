import { GoogleGenAI, Chat } from "@google/genai";
import { getMasterPrompt, avatarPersonas, getHintPrompt } from '../prompts/masterPrompt';
import type { GeminiService, AnalysisData, StreamUpdate } from '../types';

let ai: GoogleGenAI | null = null;

const kerisMajorMap: Record<string, string> = {
    "Digital Devices and Software Utilization": "디지털 기기와 소프트웨어 활용",
    "Digital Information Utilization and Creation": "디지털 정보 활용과 제작",
    "Digital Communication and Problem Solving": "디지털 소통과 문제 해결",
    "Digital Ethics and Information Security": "디지털 윤리와 정보보호",
};

const kerisSubMap: Record<string, string> = {
    "Use of Digital Devices": "디지털 기기 활용",
    "Use of Software": "소프트웨어 활용",
    "Use of Artificial Intelligence": "인공지능 활용",
    "Data Collection and Storage": "자료 수집과 저장",
    "Information Analysis and Expression": "정보 분석과 표현",
    "Digital Content Creation": "디지털 콘텐츠 제작",
    "Digital Communication": "디지털 소통",
    "Digital Problem Solving": "디지털 문제 해결",
    "Digital Ethics": "디지털 윤리",
    "Digital Information Protection": "디지털 정보 보호",
};

async function withRetry<T>(operation: () => Promise<T>, retries = 5, delay = 2000): Promise<T> {
    try {
        return await operation();
    } catch (error: any) {
        const msg = (error.message || JSON.stringify(error)).toLowerCase();
        const isRateLimit =
            msg.includes('429') ||
            msg.includes('quota') ||
            msg.includes('resource_exhausted') ||
            error.status === 429 ||
            error.code === 429;

        const isServerBusy =
            msg.includes('503') ||
            msg.includes('500') ||
            msg.includes('overloaded') ||
            error.status === 503 ||
            error.code === 503;

        if (retries > 0 && (isRateLimit || isServerBusy)) {
            const nextDelay = isRateLimit ? delay * 2.5 : delay * 2; // Rate limit needs more backoff
            console.warn(`API 호출 제한 또는 서버 혼잡. ${delay}ms 후 재시도... (남은 횟수: ${retries})`);
            await new Promise(resolve => setTimeout(resolve, delay));
            return withRetry(operation, retries - 1, nextDelay);
        }
        throw error;
    }
}

/**
 * [개선] 오프라인 테스트 모드용 DOK 분류기
 * 기존: 메시지 길이로 추정 (부정확)
 * 개선: 핵심 키워드 기반 분류 (질문 DOK와 답변 DOK 분리)
 */
function classifyQuestionDok(message: string): number {
    const text = message.trim();
    // DOK 4: 반론·다중 관점 통합이 명시된 경우만 (Webb: multiple sources + extended reasoning)
    // 단순 설계/해결책 제안은 DOK 3으로 분류 (masterPrompt 주의사항과 일치)
    if (/찬성.*반대|반대.*찬성|두 가지 입장|여러 관점|비판적으로|반론|한계점.*제시|어느 쪽이 더 설득/.test(text)) return 4;
    // DOK 3: 인과 분석, 예측, 검증, 설계/캠페인(단일 해결책)
    if (/왜|이유|원인|관계가 있을까|근거를 들어|만약.*라면|어떻게 확인|어떻게 검증|설계|캠페인|프로젝트|해결책|규칙을 만들/.test(text)) return 3;
    // DOK 2: 비교, 분류, 과정 설명
    if (/차이|비교|공통점|분류|어떻게 작동|어떤 단계|요약|특징이 뭐/.test(text)) return 2;
    // DOK 1 (기본값)
    return 1;
}

function classifyAnswerDok(message: string, questionDok: number): number {
    const text = message.trim();

    // ── DOK 1: 단순 동의, 포기, 짧은 답변 ──────────────────────────────────
    if (text.length < 20) return 1;
    if (/^(응|맞아|아|음|그래|그럴 것 같아|모르겠어|글쎄|맞는 것 같아|잘 모르겠어)/.test(text)) return 1;

    // ── DOK 4: 반론 포함 + 다중 관점 + 이유 연결 (세 조건 중 두 가지 충족) ──
    // Webb DOK 4 = multiple perspectives + extended reasoning
    // "이유", "근거" 단독은 너무 흔한 단어이므로 제외 → 강한 논리 접속어만 사용
    const hasMultiPerspective = /찬성.*반대|반대.*찬성|두 가지 입장|다른 관점|여러 측면|반론|처음에는.*생각했는데/.test(text);
    const hasStrongLogic      = /왜냐하면|따라서|그러므로/.test(text);
    // 때문에는 다중 관점 표현과 함께 있을 때만 DOK 4 신호로 인정
    const hasBecauseMulti     = hasMultiPerspective && text.includes('때문에');
    if (hasMultiPerspective && (hasStrongLogic || hasBecauseMulti)) return 4;

    // ── DOK 3: 인과 추론 (초등학생 구어체 포함) ────────────────────────────
    //
    // [강한 인과 접속어] 격식체 — 단독으로 DOK 3 인정
    const hasStrongCausal = /왜냐하면|따라서|그러므로/.test(text);
    //
    // [때문에 + 결과절] "때문에" 뒤에 8자 이상의 결과 내용이 이어질 때만 인정
    // ex) "집에 있기 때문에 더 써" (4자) → DOK 1  /  "눈이 나쁘기 때문에 생활이 불편해져" → DOK 3
    const becauseIdx = text.indexOf('때문에');
    const hasBecauseChain = becauseIdx !== -1 && text.slice(becauseIdx + 3).trim().length >= 8;
    //
    // [조건-결과 연쇄] 초등학생이 실제로 사용하는 DOK 3 구어체 패턴
    // "~(으/아/어)면 ~(게 되/것 같/수도 있/않을까)" 형태
    const hasConditionalChain = /[면]\s*.{4,}(것 같|게 되|수도 있|않을까|지 않을까)/.test(text);
    //
    // [진행-결과] "~하다 보면", "계속 ~하면" 패턴
    const hasProgressiveResult = /하다 보면|계속\s*(쓰면|하면|보면|하다\s*보면)/.test(text);
    //
    // [결과 예측 어휘] 초등학생이 예측 시 자주 쓰는 표현
    const hasChildPrediction = /나빠질|피곤해질|중독될|못 자게|집중.*못|성적.*영향|건강.*나빠|힘들어질|느려질|줄어들|생길 것|생길 수|망가질/.test(text);
    //
    // [일반 추론 패턴]
    const hasInference = /영향을 줄|영향을 미칠|결과적으로|확인할 수 있|관계가 있/.test(text);

    if (hasStrongCausal || hasBecauseChain || hasConditionalChain || hasProgressiveResult || hasChildPrediction || hasInference) return 3;

    // ── DOK 2: 비교·분류·패턴 ────────────────────────────────────────────
    if (/차이|비교|공통점|분류|반면에|보다 더|더 많이|특징은/.test(text)) return 2;

    return 1;
}

class SocraticDialogueManager {
    generateSocraticResponse(questionDok: number, answerDok: number, topic: string, avatarName: string): string {
        // 다음 안내할 DOK는 답변 DOK 기준
        const targetDok = Math.min(answerDok + 1, 4);

        const transitions: Record<string, Record<number, { encouragement: string; question: string }>> = {
            '픽셀': {
                2: {
                    encouragement: `데이터 분석 완료. 🤖 **${topic}**에 대한 기본 개념이 입력됐군요.`,
                    question: `그렇다면 시스템 비교 모드로 전환! **${topic}**과 비슷한 다른 것을 비교해보면 어떤 **차이점**이 있을까요? 🔍`
                },
                3: {
                    encouragement: `비교 분석 성공! 📈 패턴을 발견했군요.`,
                    question: `다음 단계: 인과 관계 분석. 그 차이가 생기는 **원인(이유)**은 무엇이라고 생각해요? 어떤 데이터가 그 이유를 뒷받침할 수 있을까요? 💡`
                },
                4: {
                    encouragement: `논리 회로 최고 출력! 💡 원인까지 분석했어요.`,
                    question: `최종 미션: 지금 네 주장에 **반대하는 사람**이라면 어떤 말을 할까요? 반대 입장도 정리한 뒤, 그래도 네 생각이 맞다면 어떻게 **설득**할 수 있을지 논거를 만들어봐요. 🔢`
                }
            },
            '토토': {
                2: {
                    encouragement: `멍멍! 잘했어! 🐶✨ **${topic}** 대해 알게 됐구나!`,
                    question: `이제 비교 놀이 시작! 비슷한 다른 것과 비교해보면 어떤 **차이점**이 있어? 🔍`
                },
                3: {
                    encouragement: `최고야! 🌟 비교까지 했구나!`,
                    question: `다음엔 탐정 놀이! 왜 그런 차이가 생겼을까? 그 **이유**를 찾아봐! 💡`
                },
                4: {
                    encouragement: `대단해! 🎊 이유까지 알아냈어!`,
                    question: `이제 토론 놀이! 네 생각에 **반대하는 친구**라면 뭐라고 할까? 반대 의견도 만들어보고, 그래도 네 생각이 맞다면 어떻게 **설득**할 수 있을지 써봐! 🌟`
                }
            },
            '미라': {
                2: {
                    encouragement: `별빛이 네 호기심에 응답하고 있구나... 🦉 **${topic}**의 비밀을 알게 됐단다.`,
                    question: `이제 두 별을 비교해보렴. 비슷한 것과 **차이점**은 무엇이 보이니? 🔍`
                },
                3: {
                    encouragement: `지혜의 샘이 더 깊어지고 있어... 🔮`,
                    question: `그 차이가 생기는 **이유**는 무엇이라 생각하니? 증거를 들어 이야기해주렴. 💡`
                },
                4: {
                    encouragement: `대단한 통찰이란다! 🌙 원인까지 꿰뚫어봤구나.`,
                    question: `이제 지혜의 마지막 문이란다... 네 생각에 **반대하는 입장**도 있을 거야. 그 반론을 먼저 정리하고, 그래도 네 주장이 옳다면 **두 입장을 비교해서** 어느 쪽이 더 설득력 있는지 논거를 만들어보렴. ✨`
                }
            },
            '제트': {
                2: {
                    encouragement: `미션 1단계 완료! 👨‍🚀 **${topic}** 정보 수집 성공!`,
                    question: `다음 미션: 다른 행성(상황)과 **비교** 분석! 어떤 **차이점**이 있어? 🔍`
                },
                3: {
                    encouragement: `항법 시스템 업그레이드! 🛰️ 패턴을 발견했어!`,
                    question: `탐사 심화 미션: 그 차이의 **원인**은 뭘까? 왜 그런 현상이 나타났는지 근거를 대봐! 💡`
                },
                4: {
                    encouragement: `우주 최고 발견! 🪐 인과관계까지 분석했어!`,
                    question: `최종 사령관 미션: 네 분석에 **반대하는 대원**이 있다면 뭐라고 할까? 반대 의견도 정리하고, **두 입장을 비교해서** 어느 쪽이 더 설득력 있는지 논거를 만들어봐! 🚀`
                }
            }
        };

        const persona = transitions[avatarName] || transitions['픽셀'];
        const transition = persona[targetDok] || persona[4];

        const topicExplain = `**${topic}**에 대해 생각해보고 있구나.`;
        return `${transition.encouragement}\n\n${topicExplain}\n\n${transition.question}`;
    }
}

export const geminiService: GeminiService = {
    chat: null,

    async initializeChat(avatarName: string, priorDokLevel?: number): Promise<boolean> {
        const apiKey = process.env.API_KEY;
        if (!apiKey) {
            this.chat = null;
            ai = null;
            console.warn("API 키를 찾을 수 없습니다. 오프라인 테스트 모드로 시작합니다.");
            return false;
        }
        try {
            ai = new GoogleGenAI({ apiKey });
            const systemInstruction = getMasterPrompt(avatarName);

            // [세션 승계] 이전 세션에서 측정된 DOK 수준이 있으면 히스토리에 주입
            // AI가 해당 학생의 출발점을 인지하고 적절한 수준의 발문으로 시작하게 함
            const priorDokHistory: { role: 'user' | 'model'; parts: { text: string }[] }[] = [];
            if (priorDokLevel && priorDokLevel >= 2) {
                const dokLabel: Record<number, string> = {
                    2: '기능·개념 적용(비교·분류)',
                    3: '전략적 사고(인과 추론·예측)',
                    4: '확장적 사고(다중 관점·논거 구성)',
                };
                priorDokHistory.push(
                    {
                        role: 'user',
                        parts: [{ text: '[세션 정보] 이 학생은 이전 세션에서 측정된 DOK 수준이 있습니다.' }]
                    },
                    {
                        role: 'model',
                        parts: [{ text: `[세션 인지] 이 학생의 이전 세션 최고 DOK 수준: ${priorDokLevel}단계 (${dokLabel[priorDokLevel] ?? '알 수 없음'}). 첫 응답부터 이 수준에 맞는 발문으로 시작합니다.` }]
                    }
                );
            }

            this.chat = ai.chats.create({
                model: 'gemini-3.1-flash-lite-preview',
                config: {
                    systemInstruction,
                    temperature: 0.75,
                    topP: 0.9,
                },
                history: priorDokHistory,
            });
            return true;
        } catch (error) {
            console.error("Gemini 채팅 초기화 중 오류 발생:", error);
            this.chat = null;
            ai = null;
            return false;
        }
    },

    /**
     * 학생의 답변 수준(DOK)을 분석합니다.
     * [v2 — 단일 경로] masterPrompt가 이미 JSON으로 DOK를 분류하므로
     * 별도 API 호출을 제거하고 키워드 기반 분류기를 fallback으로 사용합니다.
     * sendMessageStream()의 analysisData.answer_dok_level이 1차 정보이며,
     * 이 함수는 analysisData를 사용할 수 없는 컨텍스트에서만 호출됩니다.
     */
    async analyzeStudentThinkingLevel(message: string): Promise<number> {
        return classifyAnswerDok(message, classifyQuestionDok(message));
    },

    async sendMessage(message: string, avatarName: string) {
        const stream = this.sendMessageStream(message, avatarName);
        let finalResponse = "";
        let finalAnalysis: AnalysisData | undefined;

        for await (const update of stream) {
            finalResponse = update.text;
            if (update.analysisData) {
                finalAnalysis = update.analysisData;
            }
        }

        return {
            chatResponse: finalResponse,
            analysisData: finalAnalysis || {
                dok_level: 1,
                question_dok_level: 1,
                answer_dok_level: 1,
                dok_reasoning: "분석 데이터 없음",
                answer_quality_feedback: "분석 없음",
                keris_major: "기타",
                keris_sub: "분석 없음"
            }
        };
    },

    async *sendMessageStream(message: string, avatarName: string): AsyncGenerator<StreamUpdate, void, unknown> {
        if (!this.chat || !ai) {
            // [개선된 오프라인 테스트 모드] 키워드 기반 DOK 분류
            const questionDok = classifyQuestionDok(message);
            const answerDok = classifyAnswerDok(message, questionDok);
            const topic = message.length > 20 ? message.substring(0, 20) + "..." : message;
            const fullResponse = new SocraticDialogueManager().generateSocraticResponse(
                questionDok, answerDok, topic, avatarName
            );

            const chunkSize = 5;
            for (let i = 0; i < fullResponse.length; i += chunkSize) {
                yield { text: fullResponse.substring(0, i + chunkSize), isComplete: false };
                await new Promise(r => setTimeout(r, 20));
            }

            yield {
                text: fullResponse,
                analysisData: {
                    dok_level: answerDok,
                    question_dok_level: questionDok,
                    answer_dok_level: answerDok,
                    dok_reasoning: `[테스트 모드] 질문 DOK: ${questionDok}단계, 답변 DOK: ${answerDok}단계로 분류됐어요.`,
                    answer_quality_feedback: "API 키가 설정되지 않아 키워드 기반 테스트 모드로 응답이 생성되었습니다.",
                    keris_major: "테스트 모드",
                    keris_sub: "API 키 없음",
                },
                isComplete: true
            };
            return;
        }

        let result;
        try {
            result = await withRetry(async () => {
                if (!this.chat) throw new Error("Chat session not initialized");
                return await this.chat.sendMessageStream({ message });
            });
        } catch (error: any) {
            console.error("Gemini Request Error (Final):", error);
            const msg = (error.message || JSON.stringify(error)).toLowerCase();
            if (msg.includes('429') || msg.includes('quota') || msg.includes('resource_exhausted')) {
                yield {
                    text: "현재 너무 많은 친구들이 저와 대화하고 있어서 잠시 쉴 시간이 필요해요. 😅\n\n약 1분 뒤에 다시 말을 걸어주시겠어요? (잠시 후 페이지를 새로고침해도 좋아요!)",
                    isComplete: true
                };
            } else {
                yield {
                    text: "AI 서버와의 연결이 원활하지 않습니다. 잠시 후 다시 시도해주세요. 😥",
                    isComplete: true
                };
            }
            return;
        }

        let displayedText = "";
        let fullText = "";
        let jsonBuffer = "";
        let isAnalysisMode = false;
        const SEPARATOR = "___ANALYSIS_START___";

        try {
            for await (const chunk of result) {
                const chunkText = chunk.text;
                if (!chunkText) continue;

                fullText += chunkText;

                if (!isAnalysisMode) {
                    if (fullText.includes(SEPARATOR)) {
                        isAnalysisMode = true;
                        const parts = fullText.split(SEPARATOR);
                        displayedText = parts[0].trim();
                        jsonBuffer = parts[1] || "";
                        yield { text: displayedText, isComplete: false };
                    } else {
                        displayedText = fullText;
                        yield { text: displayedText, isComplete: false };
                    }
                } else {
                    const parts = fullText.split(SEPARATOR);
                    if (parts.length > 1) jsonBuffer = parts[1];
                }
            }

            // 기본값 (파싱 실패 시 fallback)
            let analysisData: AnalysisData = {
                dok_level: 1,
                question_dok_level: 1,
                answer_dok_level: 1,
                dok_reasoning: "분석 데이터를 생성하지 못했습니다.",
                answer_quality_feedback: "분석 없음",
                keris_major: "기타",
                keris_sub: "분석 없음"
            };

            // AI가 정상적으로 JSON을 반환했는지 추적 (5번: fallback 오염 방지)
            let aiAnalysisSucceeded = false;

            if (jsonBuffer.trim()) {
                try {
                    let cleanJson = jsonBuffer.trim();
                    
                    // Remove potential markers
                    cleanJson = cleanJson.split('___ANALYSIS_END___')[0].trim();

                    // Remove markdown code blocks
                    if (cleanJson.startsWith('```json')) cleanJson = cleanJson.replace(/^```json/, '');
                    if (cleanJson.startsWith('```')) cleanJson = cleanJson.replace(/^```/, '');
                    if (cleanJson.endsWith('```')) cleanJson = cleanJson.replace(/```$/, '');
                    
                    cleanJson = cleanJson.trim();

                    // Final attempt to extract just the JSON object if there's still garbage
                    const firstBrace = cleanJson.indexOf('{');
                    const lastBrace = cleanJson.lastIndexOf('}');
                    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
                        cleanJson = cleanJson.substring(firstBrace, lastBrace + 1);
                    }

                    const parsed = JSON.parse(cleanJson);
                    analysisData = { ...analysisData, ...parsed };

                    // answer_dok_level을 dok_level에 동기화 (하위 호환)
                    if (analysisData.answer_dok_level) {
                        analysisData.dok_level = analysisData.answer_dok_level;
                    }

                    // KERIS 영어→한국어 매핑
                    if (analysisData.keris_major && kerisMajorMap[analysisData.keris_major]) {
                        analysisData.keris_major = kerisMajorMap[analysisData.keris_major];
                    }
                    if (analysisData.keris_sub && kerisSubMap[analysisData.keris_sub]) {
                        analysisData.keris_sub = kerisSubMap[analysisData.keris_sub];
                    }

                    // AI가 7개 필드를 모두 포함한 유효한 JSON을 반환했을 때만 성공으로 판정
                    aiAnalysisSucceeded = (
                        typeof parsed.answer_dok_level === 'number' &&
                        typeof parsed.question_dok_level === 'number' &&
                        typeof parsed.dok_reasoning === 'string' &&
                        parsed.dok_reasoning.length > 0
                    );
                } catch (e) {
                    console.error("JSON Analysis parsing failed:", e, jsonBuffer);
                    aiAnalysisSucceeded = false;
                }
            }

            // [5번 강화] AI JSON 파싱이 실패한 경우에만 키워드 기반 fallback 적용.
            // AI가 정상 반환한 DOK 1 판정은 보호한다 (오염 방지).
            if (!aiAnalysisSucceeded) {
                const fallbackDok = classifyAnswerDok(message, analysisData.question_dok_level);
                console.warn(`AI 분석 실패 — 키워드 기반 fallback 적용: DOK ${fallbackDok}`);
                analysisData.answer_dok_level = fallbackDok;
                analysisData.dok_level = fallbackDok;
                analysisData.dok_reasoning = `[키워드 기반 분석] ${fallbackDok}단계로 분류됨. AI 응답 파싱 오류로 인한 대체값.`;
            }

            yield { text: displayedText, analysisData, isComplete: true };

        } catch (error: any) {
            console.error("Gemini Stream Error:", error);
            yield { text: displayedText + "\n\n[통신 오류가 발생했습니다.]", isComplete: true };
        }
    },

    async getJournalPraise(avatarName: string, learned: string, pledge: string) {
        const apiKey = process.env.API_KEY;
        if (apiKey) {
            try {
                const genAI = new GoogleGenAI({ apiKey });
                const persona = avatarPersonas[avatarName] || avatarPersonas['픽셀'];
                const prompt = `
                    You are an AI tutor for elementary school students. Your current persona is:
                    ${persona}
                    
                    A student wrote a journal entry. Based on the content below, please provide a short, specific, and encouraging praise message in Korean.
                    Speak as if you are talking to a 10-year-old, and maintain your persona's unique speaking style and emojis.
                    
                    [Journal Entry]
                    - What I learned: ${learned}
                    - What I will do: ${pledge}
                `;

                const response = await withRetry(async () => {
                    return await genAI.models.generateContent({
                        model: 'gemini-3.1-flash-lite-preview',
                        contents: prompt,
                    });
                });

                return response.text || "";

            } catch (error: any) {
                console.error("학습 일기 칭찬 생성 중 오류 발생:", error);
                const msg = (error.message || JSON.stringify(error)).toLowerCase();
                if (msg.includes("api key not valid")) {
                    return "앗, API 키가 잘못된 것 같아요. 🔑 관리자에게 문의해주세요.";
                } else if (msg.includes('429') || msg.includes('quota') || msg.includes('resource_exhausted')) {
                    return "와! 정말 멋진 일기야! (지금 너무 많은 친구들이 일기를 쓰고 있어서, AI의 구체적인 칭찬은 생략할게! 정말 잘했어! 👍)";
                }
                return "일기를 멋지게 작성했구나! 정말 대단해!";
            }
        } else {
            return new Promise((resolve) => {
                setTimeout(() => {
                    resolve(`"${pledge}" 다짐을 하다니, 정말 멋진걸! 꾸준히 실천하면 분명히 해낼 수 있을 거야! 내가 항상 응원할게! 👍`);
                }, 500);
            });
        }
    },

    async getHint(avatarName: string, lastAiMessage: string) {
        const apiKey = process.env.API_KEY;
        if (apiKey) {
            try {
                const genAI = new GoogleGenAI({ apiKey });
                const prompt = getHintPrompt(avatarName, lastAiMessage);

                const response = await withRetry(async () => {
                    return await genAI.models.generateContent({
                        model: 'gemini-3.1-flash-lite-preview',
                        contents: prompt,
                    });
                });

                return response.text || "";
            } catch (error: any) {
                console.error("힌트 생성 중 오류 발생:", error);
                const msg = (error.message || JSON.stringify(error)).toLowerCase();
                if (msg.includes('429') || msg.includes('quota') || msg.includes('resource_exhausted')) {
                    return "지금은 힌트 요정이 조금 바쁜가 봐요! 🧚‍♂️ 잠시 후에 다시 물어봐줄래?";
                }
                return "힌트를 주려다가 깜빡했어! 다시 한 번 물어봐줄래? 🤔";
            }
        } else {
            return new Promise((resolve) => {
                setTimeout(() => {
                    resolve("💡 힌트: 우리 주변에 있는 것들과 비교해보면 어떨까?");
                }, 500);
            });
        }
    }
};