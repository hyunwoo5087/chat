import { useState, useCallback, useEffect, useRef } from 'react';
import { geminiService } from '../services/geminiService';
import { analyticsService } from '../services/analyticsService';
import { TOPIC_SUGGESTIONS } from '../constants';
import type { Message, StudentData, AnalysisData, JournalEntry } from '../types';

const JOURNAL_MESSAGE_PREFIX = '[학습 일기]';

export const useChat = (studentData: StudentData) => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [journals, setJournals] = useState<JournalEntry[]>([]);

    const streamingIdRef = useRef<string | null>(null);
    // [추가] 대화 순번 추적 (세션 내 사용자 발화 횟수)
    const turnCountRef = useRef<number>(0);
    // [추가] 마지막 AI 메시지 내용 (힌트 생성에 사용)
    const lastAiMessageRef = useRef<string>('');
    // [추가] 힌트 사용 여부 플래그 (다음 턴 로그에 기록)
    const hintUsedRef = useRef<boolean>(false);

    const getCurrentTimestamp = () =>
        new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });

    useEffect(() => {
        const initialize = async () => {
            setIsLoading(true);
            try {
                const storedJournals = localStorage.getItem(`journals_${studentData.sessionId}`);
                if (storedJournals) setJournals(JSON.parse(storedJournals));

                // [세션 승계] 이전 세션의 최고 DOK 수준 불러오기
                const storedDok = localStorage.getItem(`maxDok_${studentData.sessionId}`);
                const priorDokLevel = storedDok ? parseInt(storedDok) : undefined;

                const isOnline = await geminiService.initializeChat(studentData.avatar.name, priorDokLevel);
                const welcomeMessages: Record<string, string> = {
                    '픽셀': `데이터베이스 접속 완료! 나는 너의 디지털 탐험을 도와줄 픽셀이야. 🤖 궁금한 건 뭐든지 물어봐! 체계적으로 착착 분석해줄게. 📈`,
                    '토토': `안녕 안녕! 나는 에너지 폭발 토토야! 🐶✨\n\n뭐든지 물어봐! 짱재미있게 알려줄 거야!`,
                    '미라': `고요한 밤, 지혜의 별이 반짝이는구나... 나는 너의 길을 안내할 미라란다. 🧙‍♀️🔮 디지털 세상의 어떤 신비로운 이야기가 궁금하니?`,
                    '제트': `안녕! 우주 탐험가 제트 출발 준비 완료! 👨‍🚀🚀\n\n어떤 디지털 행성을 먼저 탐험해볼까?`
                };
                const msg = isOnline
                    ? (welcomeMessages[studentData.avatar.name] || welcomeMessages['픽셀'])
                    : `AI 서버에 연결할 수 없었어요. 😥\n\n오프라인 **테스트 모드**로 대화할 수 있어요!`;
                setMessages([{ role: 'model', content: msg, timestamp: getCurrentTimestamp() }]);
                lastAiMessageRef.current = msg;
            } catch (error: any) {
                setMessages([{ role: 'model', content: `예상치 못한 오류가 발생했어요. 😥\n\n${error.message}`, timestamp: getCurrentTimestamp() }]);
            } finally {
                setIsLoading(false);
            }
        };
        initialize();
        turnCountRef.current = 0;
        hintUsedRef.current = false;
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [studentData.sessionId, studentData.avatar.name]);

    const sendMessage = useCallback(async (text: string) => {
        if (!text.trim()) return;

        // [추가] 대화 순번 증가 및 응답 시작 시각 기록
        turnCountRef.current += 1;
        const currentTurn = turnCountRef.current;
        const requestStartTime = Date.now();
        // 이 턴의 힌트 사용 여부 캡처 후 리셋
        const hintWasUsed = hintUsedRef.current;
        hintUsedRef.current = false;

        setMessages(prev => [...prev, { role: 'user', content: text, timestamp: getCurrentTimestamp() }]);
        setIsLoading(true);

        const streamId = `stream_${Date.now()}`;
        streamingIdRef.current = streamId;
        setMessages(prev => [...prev, {
            role: 'model', content: '', timestamp: getCurrentTimestamp(), _streamId: streamId
        } as any]);

        let finalContent = '';
        let finalAnalysis: AnalysisData | undefined;

        try {
            for await (const update of geminiService.sendMessageStream(text, studentData.avatar.name)) {
                finalContent = update.text;
                if (update.analysisData) finalAnalysis = update.analysisData;
                setMessages(prev => prev.map(m =>
                    (m as any)._streamId === streamId ? { ...m, content: update.text } : m
                ));
                if (update.isComplete) break;
            }

            // [추가] 응답 완료 시각 기록
            const responseTimeMs = Date.now() - requestStartTime;

            const finalMsg: Message = {
                role: 'model',
                content: finalContent,
                timestamp: getCurrentTimestamp(),
                analysisData: finalAnalysis,
            };
            setMessages(prev => prev.map(m =>
                (m as any)._streamId === streamId ? finalMsg : m
            ));

            // [추가] lastAiMessage 업데이트 (힌트 버튼이 이 메시지 기준으로 힌트 생성)
            lastAiMessageRef.current = finalContent;

            if (finalAnalysis) {
                // [세션 승계] 이번 턴 answer_dok_level이 기존 최고값보다 높으면 갱신
                const currentMax = parseInt(localStorage.getItem(`maxDok_${studentData.sessionId}`) || '1');
                const thisDok = finalAnalysis.answer_dok_level ?? 1;
                if (thisDok > currentMax) {
                    localStorage.setItem(`maxDok_${studentData.sessionId}`, String(thisDok));
                }

                const { sessionId, ...restStudentData } = studentData;
                analyticsService.logInteraction({
                    sessionId,
                    timestamp: new Date().toISOString(),
                    studentData: restStudentData,
                    userMessage: text,
                    modelResponse: { ...finalMsg, timestamp: new Date().toISOString() },
                    turnNumber: currentTurn,       // [추가]
                    hintUsed: hintWasUsed,         // [추가]
                    responseTimeMs,                // [추가]
                });
            }
        } catch (error: any) {
            setMessages(prev => prev.map(m =>
                (m as any)._streamId === streamId
                    ? { role: 'model', content: error.message || '오류가 발생했습니다. 잠시 후 다시 시도해주세요.', timestamp: getCurrentTimestamp() }
                    : m
            ));
        } finally {
            streamingIdRef.current = null;
            setIsLoading(false);
        }
    }, [studentData]);

    // [추가] 힌트 요청 핸들러
    const requestHint = useCallback(async () => {
        if (!lastAiMessageRef.current || isLoading) return;

        // 힌트 사용 플래그 설정 (다음 sendMessage 로그에 반영)
        hintUsedRef.current = true;

        setIsLoading(true);
        const hintStreamId = `hint_${Date.now()}`;
        setMessages(prev => [...prev, {
            role: 'model', content: '', timestamp: getCurrentTimestamp(),
            _streamId: hintStreamId, isHint: true
        } as any]);

        try {
            const hintText = await geminiService.getHint(
                studentData.avatar.name,
                lastAiMessageRef.current
            );
            setMessages(prev => prev.map(m =>
                (m as any)._streamId === hintStreamId
                    ? { role: 'model', content: `💡 **힌트**\n\n${hintText}`, timestamp: getCurrentTimestamp() }
                    : m
            ));
        } catch {
            setMessages(prev => prev.map(m =>
                (m as any)._streamId === hintStreamId
                    ? { role: 'model', content: '💡 조금 더 생각해봐! 할 수 있어!', timestamp: getCurrentTimestamp() }
                    : m
            ));
        } finally {
            setIsLoading(false);
        }
    }, [studentData.avatar.name, isLoading]);

    const handleTopicRoulette = useCallback(() => {
        const randomTopic = TOPIC_SUGGESTIONS[Math.floor(Math.random() * TOPIC_SUGGESTIONS.length)];
        const rouletteMessages: Record<string, string> = {
            '픽셀': `📊 시스템 분석 결과, 이 주제가 최적이야!\n\n**"${randomTopic}"**`,
            '토토': `🎲 룰렛 돌돌돌~ 띠링! 나왔다!\n\n**"${randomTopic}"**`,
            '미라': `🔮 수정구슬이 보여주는 신비로운 주제란다...\n\n**"${randomTopic}"**`,
            '제트': `🚀 미션 룰렛 가동! 슈웅~!\n\n**"${randomTopic}"**`
        };
        setMessages(prev => [...prev, {
            role: 'model',
            content: rouletteMessages[studentData.avatar.name],
            timestamp: getCurrentTimestamp()
        }]);
    }, [studentData.avatar.name]);

    const saveJournal = useCallback(async (learned: string, pledge: string) => {
        const journalEntryText = `${JOURNAL_MESSAGE_PREFIX}\n- 배운 점: ${learned}\n- 실천할 점: ${pledge}`;
        setMessages(prev => [...prev, {
            role: 'user',
            content: journalEntryText,
            timestamp: getCurrentTimestamp(),
            isJournal: true
        } as any]);

        const newEntry: JournalEntry = { learned, pledge, timestamp: new Date().toISOString() };
        const { sessionId, ...restStudentData } = studentData;
        analyticsService.logJournal({ sessionId, timestamp: new Date().toISOString(), studentData: restStudentData, journalEntry: newEntry });

        setJournals(prev => {
            const updated = [...prev, newEntry];
            localStorage.setItem(`journals_${studentData.sessionId}`, JSON.stringify(updated));
            return updated;
        });

        setIsLoading(true);
        try {
            const praise = await geminiService.getJournalPraise(studentData.avatar.name, learned, pledge);
            setMessages(prev => [...prev, { role: 'model', content: praise, timestamp: getCurrentTimestamp() }]);
            lastAiMessageRef.current = praise;
        } catch {
            setMessages(prev => [...prev, { role: 'model', content: '일기를 멋지게 작성했구나! 정말 대단해!', timestamp: getCurrentTimestamp() }]);
        } finally {
            setIsLoading(false);
        }
    }, [studentData]);

    return { messages, isLoading, journals, sendMessage, requestHint, handleTopicRoulette, saveJournal };
};

export { JOURNAL_MESSAGE_PREFIX };