
import React from 'react';
import { Trophy, Book, LogOut } from 'lucide-react';
import type { StudentData } from '../types';
import { LEVEL_THRESHOLDS } from '../constants';

interface ChatHeaderProps {
    onReset: () => void;
    studentData: StudentData;
    onJournalHistoryClick: () => void;
    onBadgeClick: () => void;
}

const ChatHeader: React.FC<ChatHeaderProps> = ({ onReset, studentData, onJournalHistoryClick, onBadgeClick }) => {
    // XP Progress Calculation
    const currentLevel = studentData.level;
    const currentXp = studentData.xp;
    const prevThreshold = LEVEL_THRESHOLDS[currentLevel - 1] || 0;
    const nextThreshold = LEVEL_THRESHOLDS[currentLevel] || (prevThreshold + 500); // Fallback for max level
    const xpNeeded = nextThreshold - prevThreshold;
    const xpInLevel = currentXp - prevThreshold;
    const progressPercent = Math.min(Math.max((xpInLevel / xpNeeded) * 100, 0), 100);

    const isTestMode = !process.env.API_KEY;

    return (
        <div className="bg-white/90 backdrop-blur-md p-3 sm:px-6 sm:py-4 flex items-center justify-between border-b border-gray-100 z-10 gap-3">
            <div className="flex items-center gap-3 sm:gap-4 overflow-hidden">
                <div className="relative flex-shrink-0">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-purple-100 to-indigo-50 rounded-2xl flex items-center justify-center text-2xl sm:text-3xl shadow-sm border border-purple-50 ring-1 ring-purple-100/50">
                        {studentData.avatar.emoji}
                    </div>
                    <div className="absolute -bottom-1 -right-1 bg-yellow-400 text-white text-[10px] sm:text-xs font-bold px-1.5 py-0.5 rounded-full shadow-sm border border-white">
                        Lv.{studentData.level}
                    </div>
                </div>
                
                <div className="flex-1 min-w-0 flex flex-col justify-center">
                    <div className="flex items-center gap-2">
                        <h1 className="text-base sm:text-lg font-bold text-gray-800 tracking-tight truncate flex items-center gap-1.5">
                            {studentData.avatar.name}
                            <span className="hidden sm:inline-flex items-center text-gray-400 font-normal text-xs sm:text-sm">
                                <span className="mx-1.5">|</span>
                                AI 튜터
                            </span>
                        </h1>
                        {isTestMode && (
                            <span className="bg-gray-100 text-gray-500 text-[10px] font-bold px-1.5 py-0.5 rounded border border-gray-200">
                                테스트 모드
                            </span>
                        )}
                    </div>
                    
                    {/* XP Bar */}
                    <div className="flex items-center gap-2 mt-0.5 sm:mt-1">
                         <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden w-20 sm:w-32">
                            <div 
                                className="h-full bg-gradient-to-r from-blue-400 to-purple-400 rounded-full transition-all duration-500"
                                style={{ width: `${progressPercent}%` }}
                            />
                        </div>
                        <span className="text-[10px] text-gray-400 font-bold whitespace-nowrap">
                            {Math.floor(currentXp)} XP
                        </span>
                    </div>
                </div>
            </div>

            <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
                 <button 
                    onClick={onBadgeClick} 
                    title="배지 보관함" 
                    className="p-2 sm:p-2.5 rounded-xl text-gray-500 hover:text-yellow-500 hover:bg-yellow-50 transition-all duration-200 group relative"
                >
                    <Trophy className="w-5 h-5 sm:w-6 sm:h-6 transition-transform group-hover:scale-110" />
                </button>
                <button 
                    onClick={onJournalHistoryClick} 
                    title="내 학습 일기" 
                    className="p-2 sm:p-2.5 rounded-xl text-gray-500 hover:text-purple-600 hover:bg-purple-50 transition-all duration-200 group"
                >
                    <Book className="w-5 h-5 sm:w-6 sm:h-6 transition-transform group-hover:scale-110" />
                </button>
                <button 
                    onClick={onReset} 
                    title="종료하기" 
                    className="p-2 sm:p-2.5 rounded-xl text-gray-500 hover:text-red-500 hover:bg-red-50 transition-all duration-200 group"
                >
                    <LogOut className="w-5 h-5 sm:w-6 sm:h-6 transition-transform group-hover:scale-110" />
                </button>
            </div>
        </div>
    );
};

export default ChatHeader;
