
import React from 'react';
import { X, FileText, Calendar, Clock, ChevronRight, BookOpen, Target } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { JournalEntry } from '../types';

interface JournalHistoryModalProps {
    isOpen: boolean;
    onClose: () => void;
    journals: JournalEntry[];
}

const JournalHistoryModal: React.FC<JournalHistoryModalProps> = ({ isOpen, onClose, journals }) => {
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.05
            }
        }
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 10 },
        visible: { opacity: 1, y: 0 }
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="absolute inset-0 bg-black/60 backdrop-blur-md"
                    />
                    
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 20 }}
                        className="bg-white rounded-[40px] shadow-2xl w-full max-w-2xl h-[85vh] flex flex-col overflow-hidden relative z-10 border border-white/20"
                    >
                        {/* Header */}
                        <div className="p-8 pb-6 border-b border-gray-50 flex justify-between items-center bg-white/80 backdrop-blur-sm sticky top-0 z-20">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center">
                                    <BookOpen className="w-6 h-6 text-purple-600" />
                                </div>
                                <div>
                                    <h2 className="text-2xl font-extrabold text-gray-900">나의 성장 기록</h2>
                                    <p className="text-sm text-gray-500 font-medium">지금까지 작성한 {journals.length}개의 일기</p>
                                </div>
                            </div>
                            <button 
                                onClick={onClose} 
                                className="text-gray-400 hover:text-gray-600 transition-colors p-2 hover:bg-gray-100 rounded-full"
                            >
                                <X className="w-6 h-6" />
                            </button>
                        </div>
                        
                        {/* Content */}
                        <div className="flex-1 overflow-y-auto p-8 bg-gray-50/30 custom-scrollbar">
                            {journals.length > 0 ? (
                                <motion.div 
                                    variants={containerVariants}
                                    initial="hidden"
                                    animate="visible"
                                    className="space-y-6"
                                >
                                    {journals.slice().reverse().map((entry, index) => (
                                        <motion.div 
                                            key={index} 
                                            variants={itemVariants}
                                            className="bg-white rounded-[32px] p-8 shadow-sm border border-gray-100/50 hover:border-purple-200 transition-all duration-300 group relative overflow-hidden"
                                        >
                                            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-purple-500/5 to-indigo-500/5 -z-10 rounded-full -mr-16 -mt-16 group-hover:scale-110 transition-transform" />
                                            
                                            <div className="flex items-center justify-between mb-6">
                                                <div className="flex items-center gap-4">
                                                    <div className="flex items-center gap-1.5 text-xs font-extrabold text-purple-600 bg-purple-50 px-3 py-1.5 rounded-full">
                                                        <Calendar className="w-3 h-3" />
                                                        {new Date(entry.timestamp).toLocaleDateString('ko-KR', { month: 'long', day: 'numeric' })}
                                                    </div>
                                                    <div className="flex items-center gap-1.5 text-xs font-bold text-gray-400">
                                                        <Clock className="w-3 h-3" />
                                                        {new Date(entry.timestamp).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}
                                                    </div>
                                                </div>
                                                <ChevronRight className="w-5 h-5 text-gray-200 group-hover:text-purple-300 transition-colors" />
                                            </div>
                                            
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                                <div className="space-y-3">
                                                    <div className="flex items-center gap-2">
                                                        <div className="w-1.5 h-1.5 rounded-full bg-yellow-400" />
                                                        <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Learned</h3>
                                                    </div>
                                                    <p className="text-gray-800 text-base leading-relaxed font-medium">
                                                        {entry.learned}
                                                    </p>
                                                </div>
                                                <div className="space-y-3">
                                                    <div className="flex items-center gap-2">
                                                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                                                        <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Pledge</h3>
                                                    </div>
                                                    <p className="text-gray-800 text-base leading-relaxed font-medium italic">
                                                        "{entry.pledge}"
                                                    </p>
                                                </div>
                                            </div>
                                        </motion.div>
                                    ))}
                                </motion.div>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-center p-12">
                                    <div className="w-24 h-24 bg-white rounded-[32px] shadow-xl shadow-gray-200/50 flex items-center justify-center mb-8 text-gray-200 animate-float">
                                        <FileText className="w-10 h-10" />
                                    </div>
                                    <h3 className="text-2xl font-extrabold text-gray-900 mb-3">아직 기록이 없어요</h3>
                                    <p className="text-gray-400 font-medium max-w-[240px] leading-relaxed">
                                        AI와 대화를 나누고 오늘 배운 점을 일기로 남겨보세요!
                                    </p>
                                </div>
                            )}
                        </div>
                        
                        {/* Footer */}
                        <div className="p-8 bg-white border-t border-gray-50">
                            <button 
                                onClick={onClose} 
                                className="w-full py-5 bg-gray-900 hover:bg-black text-white font-bold rounded-2xl shadow-xl shadow-gray-200 transition-all active:scale-[0.98]"
                            >
                                돌아가기
                            </button>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
};

export default JournalHistoryModal;
