
import React, { useState } from 'react';
import { X, BookOpen, Target, Sparkles, ChevronRight, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface JournalModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (learned: string, pledge: string) => void;
}

const JournalModal: React.FC<JournalModalProps> = ({ isOpen, onClose, onSave }) => {
    const [learned, setLearned] = useState('');
    const [pledge, setPledge] = useState('');
    const [step, setStep] = useState(1);

    const handleSave = () => {
        if (learned.trim() && pledge.trim()) {
            onSave(learned, pledge);
            setLearned('');
            setPledge('');
            setStep(1);
            onClose();
        }
    };

    const nextStep = () => {
        if (step === 1 && learned.trim()) setStep(2);
    };

    const prevStep = () => {
        if (step === 2) setStep(1);
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="absolute inset-0 bg-black/60 backdrop-blur-md"
                    />
                    
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 20 }}
                        className="bg-white rounded-[40px] shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90dvh] relative z-10 border border-white/20"
                    >
                        {/* Progress Bar */}
                        <div className="absolute top-0 left-0 w-full h-1.5 bg-gray-100">
                            <motion.div 
                                className="h-full bg-gradient-to-r from-purple-500 to-indigo-600"
                                initial={{ width: "0%" }}
                                animate={{ width: step === 1 ? "50%" : "100%" }}
                                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                            />
                        </div>

                        {/* Header */}
                        <div className="p-8 sm:p-10 pb-4 flex justify-between items-start">
                            <div className="space-y-2">
                                <div className="flex items-center gap-2">
                                    <span className="px-3 py-1 bg-purple-100 text-purple-700 text-[10px] font-bold uppercase tracking-[0.15em] rounded-full">
                                        Step {step} of 2
                                    </span>
                                </div>
                                <h2 className="text-3xl font-bold text-gray-900 tracking-tight">
                                    {step === 1 ? "무엇을 배웠나요?" : "어떻게 실천할까요?"}
                                </h2>
                                <p className="text-sm text-gray-500 font-medium">
                                    {step === 1 ? "오늘 대화하며 새롭게 알게 된 내용을 정리해봐요." : "배운 내용을 우리 생활에서 어떻게 활용할지 약속해요."}
                                </p>
                            </div>
                            <button 
                                onClick={onClose} 
                                className="text-gray-400 hover:text-gray-600 transition-all p-2.5 rounded-2xl hover:bg-gray-100 active:scale-90"
                            >
                                <X className="w-6 h-6" />
                            </button>
                        </div>

                        {/* Content */}
                        <div className="flex-1 overflow-hidden relative">
                            <AnimatePresence mode="wait">
                                {step === 1 ? (
                                    <motion.div
                                        key="step1"
                                        initial={{ opacity: 0, x: 20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        exit={{ opacity: 0, x: -20 }}
                                        className="p-8 sm:p-10 pt-0 h-full flex flex-col"
                                    >
                                        <div className="flex-1 space-y-6">
                                            <div className="bg-white rounded-[32px] p-8 border-2 border-purple-100 shadow-sm group focus-within:border-purple-400 focus-within:shadow-md transition-all duration-300">
                                                <div className="flex items-center gap-3.5 mb-6">
                                                    <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center border border-purple-100 group-focus-within:bg-white transition-all">
                                                        <BookOpen className="w-6 h-6 text-purple-600" />
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-bold text-purple-900">오늘의 새로운 발견</p>
                                                        <p className="text-[10px] text-purple-400 font-medium">Learning Log</p>
                                                    </div>
                                                </div>
                                                <textarea
                                                    id="learnedContent"
                                                    autoFocus
                                                    value={learned}
                                                    onChange={(e) => setLearned(e.target.value)}
                                                    rows={6}
                                                    placeholder="오늘 새롭게 알게 된 사실이나 느낀 점을 자유롭게 적어보세요..."
                                                    className="w-full bg-transparent border-none focus:ring-0 outline-none text-gray-800 placeholder-purple-200 text-xl resize-none leading-relaxed min-h-[200px] p-0"
                                                />
                                            </div>
                                            <div className="flex items-center gap-2.5 text-xs text-indigo-400 font-bold px-4 py-3 bg-indigo-50/30 rounded-2xl border border-indigo-50/50">
                                                <Sparkles className="w-4 h-4 animate-pulse" />
                                                <span>생각을 정리하면 기억에 더 오래 남아요!</span>
                                            </div>
                                        </div>
                                    </motion.div>
                                ) : (
                                    <motion.div
                                        key="step2"
                                        initial={{ opacity: 0, x: 20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        exit={{ opacity: 0, x: -20 }}
                                        className="p-8 sm:p-10 pt-0 h-full flex flex-col"
                                    >
                                        <div className="flex-1 space-y-6">
                                            <div className="bg-white rounded-[32px] p-8 border-2 border-indigo-100 shadow-sm group focus-within:border-indigo-400 focus-within:shadow-md transition-all duration-300">
                                                <div className="flex items-center gap-3.5 mb-6">
                                                    <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center border border-indigo-100 group-focus-within:bg-white transition-all">
                                                        <Target className="w-6 h-6 text-indigo-600" />
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-bold text-indigo-900">나의 다짐과 약속</p>
                                                        <p className="text-[10px] text-indigo-400 font-medium">Future Action</p>
                                                    </div>
                                                </div>
                                                <textarea
                                                    id="pledgeContent"
                                                    autoFocus
                                                    value={pledge}
                                                    onChange={(e) => setPledge(e.target.value)}
                                                    rows={6}
                                                    placeholder="배운 내용을 바탕으로 앞으로 어떻게 행동하고 싶은지 적어보세요..."
                                                    className="w-full bg-transparent border-none focus:ring-0 outline-none text-gray-800 placeholder-indigo-200 text-xl resize-none leading-relaxed min-h-[200px] p-0"
                                                />
                                            </div>
                                            <div className="flex items-center gap-2.5 text-xs text-emerald-500 font-bold px-4 py-3 bg-emerald-50/30 rounded-2xl border border-emerald-50/50">
                                                <Check className="w-4 h-4" />
                                                <span>작은 실천이 큰 변화를 만들어요!</span>
                                            </div>
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>

                        {/* Footer */}
                        <div className="p-8 sm:p-10 bg-gray-50/80 border-t border-gray-100 flex gap-4">
                            {step === 2 && (
                                <button
                                    onClick={prevStep}
                                    className="px-8 py-4.5 bg-white hover:bg-gray-100 text-gray-600 font-bold rounded-2xl transition-all border border-gray-200 shadow-sm active:scale-95"
                                >
                                    이전
                                </button>
                            )}
                            
                            {step === 1 ? (
                                <button 
                                    onClick={nextStep} 
                                    disabled={!learned.trim()}
                                    className={`flex-1 py-4.5 rounded-2xl font-bold text-lg shadow-xl transition-all duration-300 transform active:scale-[0.98] flex items-center justify-center gap-3 ${
                                        !learned.trim()
                                        ? 'bg-gray-200 text-gray-400 cursor-not-allowed shadow-none'
                                        : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-purple-500/30 hover:shadow-purple-500/40 hover:-translate-y-1'
                                    }`}
                                >
                                    다음 단계로
                                    <ChevronRight className="w-5 h-5" />
                                </button>
                            ) : (
                                <button 
                                    onClick={handleSave} 
                                    disabled={!pledge.trim()}
                                    className={`flex-1 py-4.5 rounded-2xl font-bold text-lg shadow-xl transition-all duration-300 transform active:scale-[0.98] flex items-center justify-center gap-3 ${
                                        !pledge.trim()
                                        ? 'bg-gray-200 text-gray-400 cursor-not-allowed shadow-none'
                                        : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-purple-500/30 hover:shadow-purple-500/40 hover:-translate-y-1'
                                    }`}
                                >
                                    <Sparkles className="w-5 h-5 animate-pulse" />
                                    일기 저장하기
                                </button>
                            )}
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
};

export default JournalModal;
