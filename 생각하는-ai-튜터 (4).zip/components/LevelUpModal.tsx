import React from 'react';
import confetti from 'canvas-confetti';
import { LEVEL_META, LEVEL_THRESHOLDS } from '../constants';

interface LevelUpModalProps {
    isOpen: boolean;
    level: number;
    onClose: () => void;
}

const LevelUpModal: React.FC<LevelUpModalProps> = ({ isOpen, level, onClose }) => {
    if (!isOpen) return null;

    const meta = LEVEL_META[level] ?? { name: `레벨 ${level}`, subtitle: '계속 성장하고 있어요!', color: 'from-yellow-400 to-orange-500' };
    const nextMeta = LEVEL_META[level + 1];
    const nextThreshold = LEVEL_THRESHOLDS[level] ?? null;

    React.useEffect(() => {
        if (isOpen) {
            const duration = 3 * 1000;
            const animationEnd = Date.now() + duration;
            const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };
            const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;
            const interval: any = setInterval(function() {
                const timeLeft = animationEnd - Date.now();
                if (timeLeft <= 0) return clearInterval(interval);
                const particleCount = 50 * (timeLeft / duration);
                confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
                confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
            }, 250);
            return () => clearInterval(interval);
        }
    }, [isOpen]);

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-[100] p-4">
            <div className="bg-white rounded-[40px] shadow-2xl w-full max-w-sm overflow-hidden animate-bounce-in relative">
                {/* 헤더 그라디언트 — 레벨별 색상 */}
                <div className={`absolute top-0 left-0 w-full h-32 bg-gradient-to-br ${meta.color}`} />

                <div className="relative pt-12 pb-8 px-8 text-center">
                    {/* 레벨 배지 */}
                    <div className="w-24 h-24 bg-white rounded-3xl shadow-xl mx-auto flex items-center justify-center mb-4 border-4 border-yellow-400 transform -rotate-6 animate-float">
                        <div className="text-center">
                            <p className="text-xs font-bold text-gray-400 uppercase">Lv.</p>
                            <p className={`text-4xl font-black text-transparent bg-clip-text bg-gradient-to-br ${meta.color}`}>
                                {level}
                            </p>
                        </div>
                    </div>

                    {/* 레벨 명칭 */}
                    <h2 className="text-2xl font-black text-gray-900 mb-1">레벨 업! 🎉</h2>
                    <p className={`text-lg font-extrabold text-transparent bg-clip-text bg-gradient-to-r ${meta.color} mb-1`}>
                        {meta.name}
                    </p>
                    <p className="text-sm text-gray-500 font-medium mb-5 break-keep leading-relaxed">
                        {meta.subtitle}
                    </p>

                    {/* 다음 레벨 미리보기 */}
                    {nextMeta && nextThreshold && (
                        <div className="bg-gray-50 rounded-2xl px-4 py-3 mb-6 text-left border border-gray-100">
                            <p className="text-xs font-bold text-gray-400 uppercase tracking-wide mb-1">다음 목표</p>
                            <p className="text-sm font-bold text-gray-700">
                                Lv.{level + 1} <span className={`text-transparent bg-clip-text bg-gradient-to-r ${nextMeta.color}`}>{nextMeta.name}</span>
                            </p>
                            <p className="text-xs text-gray-400 mt-0.5">{nextMeta.subtitle}</p>
                            <p className="text-xs text-gray-300 mt-1">목표 XP: {nextThreshold}</p>
                        </div>
                    )}
                    {!nextMeta && (
                        <div className="bg-yellow-50 rounded-2xl px-4 py-3 mb-6 border border-yellow-100">
                            <p className="text-sm font-bold text-yellow-700">🏆 최고 레벨 달성! 대단해요!</p>
                        </div>
                    )}

                    <button
                        onClick={onClose}
                        className={`w-full py-4 bg-gradient-to-r ${meta.color} hover:opacity-90 text-white font-black rounded-2xl shadow-lg transition-all active:scale-95`}
                    >
                        계속 도전하기 ✨
                    </button>
                </div>
            </div>
        </div>
    );
};

export default LevelUpModal;

