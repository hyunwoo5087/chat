import React, { useMemo } from 'react';
import type { Message, StudentData, Badge } from '../types';
import { BADGES } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, BarChart3, Globe, Award, MessageSquare, ChevronRight, Sparkles } from 'lucide-react';

interface SessionSummaryModalProps {
    isOpen: boolean;
    studentData: StudentData;
    messages: Message[];
    onConfirm: () => void; // 실제 종료
    onCancel: () => void;  // 계속 대화
}

interface SessionStats {
    userMsgCount: number;
    maxDok: number;
    dokDist: Record<number, number>;
    exploredAreas: string[];
    earnedBadges: Badge[];
}

const SessionSummaryModal: React.FC<SessionSummaryModalProps> = ({
    isOpen, studentData, messages, onConfirm, onCancel
}) => {
    // ── 세션 통계 계산 ────────────────────────────────────────
    const stats = useMemo<SessionStats>(() => {
        const userMsgs = messages.filter(m => m.role === 'user' && !(m as any).isJournal);
        const aiMsgs = messages.filter((m): m is Message & { analysisData: NonNullable<Message['analysisData']> } => 
            m.role === 'model' && !!m.analysisData
        );

        // 최고 DOK 단계
        const maxDok = aiMsgs.reduce((max, m) =>
            Math.max(max, m.analysisData.answer_dok_level), 0);

        // DOK 분포 (1~4 각 몇 번)
        const dokDist: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0 };
        aiMsgs.forEach(m => {
            const lvl = m.analysisData.answer_dok_level;
            if (lvl >= 1 && lvl <= 4) dokDist[lvl]++;
        });

        // 탐색한 KERIS 대영역 (중복 제거)
        // geminiService에서 이미 한국어로 변환된 값이 저장되므로 한국어 키로 매핑
        const kerisEmojiMap: Record<string, string> = {
            '디지털 기기와 소프트웨어 활용': '💻 디지털 기기와 소프트웨어 활용',
            '디지털 정보 활용과 제작': '📊 디지털 정보 활용과 제작',
            '디지털 소통과 문제 해결': '💬 디지털 소통과 문제 해결',
            '디지털 윤리와 정보보호': '🛡️ 디지털 윤리와 정보보호',
        };
        const exploredAreas: string[] = [...new Set(
            aiMsgs.map(m => m.analysisData.keris_major).filter(Boolean)
        )].map((k: string) => kerisEmojiMap[k] ?? k);

        // 세션 내 새로 획득한 배지 (현재 보유 배지 전체 표시)
        const earnedBadges = BADGES.filter(b => studentData.badges.includes(b.id));

        return { userMsgCount: userMsgs.length, maxDok, dokDist, exploredAreas, earnedBadges };
    }, [messages, studentData.badges]);

    const dokLabels: Record<number, string> = {
        1: '기억하기', 2: '비교하기', 3: '추론하기', 4: '창조하기'
    };
    const dokColors: Record<number, string> = {
        1: 'bg-blue-400', 2: 'bg-emerald-400', 3: 'bg-amber-400', 4: 'bg-violet-500'
    };
    const maxDokLabel: Record<number, { emoji: string; text: string; color: string; bg: string }> = {
        0: { emoji: '🌱', text: '아직 시작 전이에요', color: 'text-gray-500', bg: 'bg-gray-50' },
        1: { emoji: '📝', text: '사실을 정확하게 기억했어요!', color: 'text-blue-600', bg: 'bg-blue-50' },
        2: { emoji: '🔍', text: '비교하고 패턴을 잘 찾아냈어요!', color: 'text-emerald-600', bg: 'bg-emerald-50' },
        3: { emoji: '💡', text: '이유와 원인을 논리적으로 추론했어요!', color: 'text-amber-600', bg: 'bg-amber-50' },
        4: { emoji: '🚀', text: '새로운 아이디어로 문제를 해결했어요!', color: 'text-violet-600', bg: 'bg-violet-50' },
    };
    const maxDokInfo = maxDokLabel[stats.maxDok as keyof typeof maxDokLabel] ?? maxDokLabel[0];
    const totalAiResponses = [1, 2, 3, 4].reduce((acc, lvl) => acc + (stats.dokDist[lvl] || 0), 0);

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1
            }
        }
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0 }
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onCancel}
                        className="absolute inset-0 bg-black/60 backdrop-blur-md"
                    />
                    
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 20 }}
                        className="bg-white rounded-[40px] shadow-2xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col relative z-10 border border-white/20"
                    >
                        {/* Header */}
                        <div className="bg-gradient-to-br from-purple-600 via-indigo-600 to-indigo-800 p-8 sm:p-10 text-white relative overflow-hidden">
                            {/* Decorative Elements */}
                            <div className="absolute -top-10 -right-10 w-48 h-48 bg-white/10 rounded-full blur-3xl" />
                            <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-purple-400/20 rounded-full blur-3xl" />
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full opacity-5 pointer-events-none">
                                <div className="grid grid-cols-6 gap-4 rotate-12">
                                    {Array.from({ length: 24 }).map((_, i) => (
                                        <Sparkles key={i} className="w-8 h-8" />
                                    ))}
                                </div>
                            </div>
                            
                            <div className="relative z-10 flex flex-col items-center text-center">
                                <motion.div 
                                    initial={{ scale: 0, rotate: -20 }}
                                    animate={{ scale: 1, rotate: 0 }}
                                    transition={{ type: "spring", delay: 0.2 }}
                                    className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-3xl flex items-center justify-center mb-6 border border-white/30 shadow-2xl"
                                >
                                    <Trophy className="w-10 h-10 text-yellow-300 drop-shadow-lg" />
                                </motion.div>
                                <h2 className="text-3xl font-bold tracking-tight mb-4 drop-shadow-sm">오늘의 학습 리포트</h2>
                                <div className="flex flex-wrap justify-center items-center gap-x-3 gap-y-2 px-5 py-2.5 bg-white/20 backdrop-blur-md rounded-2xl text-white font-bold text-sm border border-white/30 shadow-xl max-w-[92%] mx-auto">
                                    <span className="truncate max-w-[160px] sm:max-w-[240px]">{studentData.school}</span>
                                    <span className="w-1 h-1 bg-white/40 rounded-full flex-shrink-0 hidden sm:block" />
                                    <span className="whitespace-nowrap">
                                        {studentData.grade} {studentData.class} {studentData.studentNumber}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto custom-scrollbar p-6 sm:p-10">
                            <motion.div 
                                variants={containerVariants}
                                initial="hidden"
                                animate="visible"
                                className="space-y-10"
                            >
                                {/* 최고 DOK 달성 */}
                                <motion.div variants={itemVariants} className={`${maxDokInfo.bg} rounded-[40px] p-8 text-center border border-white shadow-xl relative overflow-hidden group`}>
                                    <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:scale-110 transition-transform duration-500">
                                        <Award className="w-24 h-24" />
                                    </div>
                                    <div className="relative z-10">
                                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em] mb-4">Today's Peak Thinking</p>
                                        <div className="text-7xl mb-6 drop-shadow-xl transform group-hover:scale-110 transition-transform duration-500">{maxDokInfo.emoji}</div>
                                        <h3 className={`font-bold text-3xl mb-3 ${maxDokInfo.color}`}>
                                            {stats.maxDok > 0 ? `DOK ${stats.maxDok}단계 달성!` : '탐색을 시작해봐요!'}
                                        </h3>
                                        <p className="text-base text-gray-500 font-medium leading-relaxed break-keep max-w-[320px] mx-auto">
                                            {maxDokInfo.text}
                                        </p>
                                    </div>
                                </motion.div>

                                {/* DOK 분포 바 */}
                                {totalAiResponses > 0 && (
                                    <motion.div variants={itemVariants} className="space-y-6">
                                        <div className="flex items-center justify-between px-2">
                                            <div className="flex items-center gap-2.5">
                                                <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                                                    <BarChart3 className="w-4 h-4 text-gray-500" />
                                                </div>
                                                <p className="text-sm font-bold text-gray-800 uppercase tracking-wider">AI 사고 분석 리포트</p>
                                            </div>
                                            <span className="text-[10px] font-bold text-gray-400 bg-gray-50 px-2 py-1 rounded-md">총 {totalAiResponses}회 분석</span>
                                        </div>
                                        <div className="bg-gray-50/50 rounded-[40px] p-8 border border-gray-100 space-y-6 shadow-inner relative overflow-hidden">
                                            <div className="absolute -top-10 -right-10 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl" />
                                            {([1, 2, 3, 4] as const).map(lvl => {
                                                const count = stats.dokDist[lvl];
                                                const pct = totalAiResponses > 0 ? Math.round((count / totalAiResponses) * 100) : 0;
                                                const dokEmojiMap: Record<number, string> = { 1: '📝', 2: '🔍', 3: '💡', 4: '🚀' };
                                                return (
                                                    <div key={lvl} className="space-y-3">
                                                        <div className="flex justify-between items-end px-1">
                                                            <div className="flex items-center gap-2">
                                                                <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-lg shadow-sm bg-white border border-gray-100`}>
                                                                    {dokEmojiMap[lvl]}
                                                                </div>
                                                                <div className="flex flex-col">
                                                                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tight">{lvl}단계</span>
                                                                    <span className="text-sm font-bold text-gray-700 leading-none">{dokLabels[lvl]}</span>
                                                                </div>
                                                            </div>
                                                            <div className="text-right">
                                                                <span className="text-xs font-bold text-gray-400">{count}회</span>
                                                                <span className="mx-1.5 text-gray-200">|</span>
                                                                <span className="text-sm font-black text-indigo-500">{pct}%</span>
                                                            </div>
                                                        </div>
                                                        <div className="h-3.5 bg-white rounded-full overflow-hidden border border-gray-100 shadow-sm p-0.5">
                                                            <motion.div
                                                                initial={{ width: 0 }}
                                                                animate={{ width: `${pct}%` }}
                                                                transition={{ duration: 1.2, ease: [0.34, 1.56, 0.64, 1] }}
                                                                className={`h-full rounded-full ${dokColors[lvl]} shadow-sm relative`}
                                                            >
                                                                {pct > 10 && (
                                                                    <div className="absolute inset-0 bg-gradient-to-r from-white/30 to-transparent" />
                                                                )}
                                                            </motion.div>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </motion.div>
                                )}

                                {/* 오늘 탐색한 KERIS 영역 */}
                                {stats.exploredAreas.length > 0 && (
                                    <motion.div variants={itemVariants} className="space-y-5">
                                        <div className="flex items-center gap-2.5 px-2">
                                            <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                                                <Globe className="w-4 h-4 text-gray-500" />
                                            </div>
                                            <p className="text-sm font-bold text-gray-800 uppercase tracking-wider">탐색한 디지털 역량</p>
                                        </div>
                                        <div className="flex flex-wrap gap-3">
                                            {stats.exploredAreas.map(area => (
                                                <motion.span 
                                                    key={area} 
                                                    whileHover={{ scale: 1.05 }}
                                                    className="text-xs bg-white text-indigo-700 font-bold px-5 py-3 rounded-2xl border border-indigo-50 shadow-sm hover:border-indigo-200 hover:bg-indigo-50 transition-all cursor-default"
                                                >
                                                    {area}
                                                </motion.span>
                                            ))}
                                        </div>
                                    </motion.div>
                                )}

                                {/* 획득한 배지 */}
                                {stats.earnedBadges.length > 0 && (
                                    <motion.div variants={itemVariants} className="space-y-5">
                                        <div className="flex items-center gap-2.5 px-2">
                                            <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                                                <Award className="w-4 h-4 text-gray-500" />
                                            </div>
                                            <p className="text-sm font-bold text-gray-800 uppercase tracking-wider">보유 배지</p>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                            {stats.earnedBadges.map(b => (
                                                <motion.div 
                                                    key={b.id} 
                                                    whileHover={{ y: -2 }}
                                                    className="flex items-center gap-4 bg-amber-50/40 p-4 rounded-[24px] border border-amber-100/50 shadow-sm"
                                                >
                                                    <div className="text-3xl drop-shadow-sm">{b.icon}</div>
                                                    <div className="flex flex-col">
                                                        <span className="text-xs font-bold text-amber-900">{b.name}</span>
                                                        <span className="text-[10px] text-amber-600/70 font-medium">획득 완료</span>
                                                    </div>
                                                </motion.div>
                                            ))}
                                        </div>
                                    </motion.div>
                                )}

                                {/* XP / 대화수 / 레벨 요약 */}
                                <motion.div variants={itemVariants} className="grid grid-cols-3 gap-4">
                                    <div className="bg-white rounded-[32px] p-6 text-center border border-gray-100 shadow-sm group hover:bg-indigo-50 transition-all duration-300">
                                        <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-white group-hover:shadow-md transition-all">
                                            <Sparkles className="w-6 h-6 text-indigo-600" />
                                        </div>
                                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">XP</p>
                                        <p className="text-2xl font-bold text-gray-900">{studentData.xp}</p>
                                    </div>
                                    <div className="bg-white rounded-[32px] p-6 text-center border border-gray-100 shadow-sm group hover:bg-purple-50 transition-all duration-300">
                                        <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-white group-hover:shadow-md transition-all">
                                            <Award className="w-6 h-6 text-purple-600" />
                                        </div>
                                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">LV</p>
                                        <p className="text-2xl font-bold text-gray-900">{studentData.level}</p>
                                    </div>
                                    <div className="bg-white rounded-[32px] p-6 text-center border border-gray-100 shadow-sm group hover:bg-emerald-50 transition-all duration-300">
                                        <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-white group-hover:shadow-md transition-all">
                                            <MessageSquare className="w-6 h-6 text-emerald-600" />
                                        </div>
                                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">MSG</p>
                                        <p className="text-2xl font-bold text-gray-900">{stats.userMsgCount}</p>
                                    </div>
                                </motion.div>
                            </motion.div>
                        </div>

                        {/* 버튼 */}
                        <div className="p-8 sm:p-10 bg-gray-50/80 border-t border-gray-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <button
                                onClick={onCancel}
                                className="py-4.5 bg-white hover:bg-gray-100 text-gray-600 font-bold rounded-2xl transition-all border border-gray-200 shadow-sm active:scale-95 flex items-center justify-center gap-2.5"
                            >
                                <MessageSquare className="w-5 h-5" />
                                계속 대화하기
                            </button>
                            <button
                                onClick={onConfirm}
                                className="py-4.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold rounded-2xl transition-all shadow-xl shadow-indigo-200 active:scale-95 flex items-center justify-center gap-2.5 group"
                            >
                                학습 마치기
                                <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                            </button>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
};

export default SessionSummaryModal;
