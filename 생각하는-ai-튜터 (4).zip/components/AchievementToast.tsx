
import React, { useEffect, useState } from 'react';

export type AchievementType = 'dok' | 'badge' | 'levelup';

interface AchievementToastProps {
    type: AchievementType;
    data: {
        level?: number;
        badgeName?: string;
        badgeIcon?: string;
        xp?: number;
    };
    onClose: () => void;
}

const AchievementToast: React.FC<AchievementToastProps> = ({ type, data, onClose }) => {
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        setIsVisible(true);
        const timer = setTimeout(() => {
            setIsVisible(false);
            setTimeout(onClose, 500); // Wait for exit animation
        }, 4000);

        return () => clearTimeout(timer);
    }, [onClose]);

    let content = {
        title: "",
        desc: "",
        icon: "",
        gradient: "",
        shadow: ""
    };

    if (type === 'dok') {
        const level = data.level || 0;
        if (level === 4) {
            content = {
                title: "🌟 최고 수준 달성! 🌟",
                desc: `여러 관점을 통합해 논거를 만들었어요! (+${data.xp ?? 70} XP)`,
                icon: "🧙",
                gradient: "from-violet-500 via-purple-500 to-fuchsia-500",
                shadow: "shadow-purple-500/40"
            };
        } else if (level === 3) {
            content = {
                title: "✨ 논리왕 발견! ✨",
                desc: `이유를 찾고 깊게 생각했어요! (+${data.xp ?? 40} XP)`,
                icon: "💡",
                gradient: "from-amber-400 via-orange-500 to-red-500",
                shadow: "shadow-orange-500/40"
            };
        } else {
            // DOK 2
            content = {
                title: "👍 비교 탐구 성공!",
                desc: `비교하고 분류하는 사고를 보여줬어요! (+${data.xp ?? 15} XP)`,
                icon: "⚖️",
                gradient: "from-blue-400 via-cyan-500 to-teal-500",
                shadow: "shadow-cyan-500/40"
            };
        }
    } else if (type === 'badge') {
        content = {
            title: "🏆 새로운 배지 획득! 🏆",
            desc: `'${data.badgeName}' 배지를 받았어요!`,
            icon: data.badgeIcon || "🎖️",
            gradient: "from-yellow-400 via-orange-400 to-yellow-500",
            shadow: "shadow-yellow-500/40"
        };
    } else if (type === 'levelup') {
        content = {
            title: "🎉 레벨 업! 🎉",
            desc: `축하해요! 레벨 ${data.level}이 되었어요!`,
            icon: "🆙",
            gradient: "from-emerald-400 via-teal-500 to-cyan-500",
            shadow: "shadow-teal-500/40"
        };
    }

    return (
        <div className={`fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 pointer-events-none transition-all duration-500 ease-out ${isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90 translate-y-4'}`}>
            <div className={`relative bg-white rounded-3xl p-1 shadow-2xl ${content.shadow} animate-bounce-gentle`}>
                <div className={`absolute -top-10 left-1/2 -translate-x-1/2 text-6xl filter drop-shadow-md animate-wiggle`}>
                    {content.icon}
                </div>
                <div className="bg-white rounded-[20px] px-8 py-6 pt-10 text-center border border-gray-100 min-w-[300px]">
                    <h3 className={`text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r ${content.gradient} mb-2`}>
                        {content.title}
                    </h3>
                    <p className="text-gray-600 font-medium break-keep leading-relaxed">
                        {content.desc}
                    </p>
                </div>
                {/* Shining effect */}
                <div className="absolute inset-0 rounded-3xl overflow-hidden">
                    <div className="absolute top-0 -left-full w-1/2 h-full bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12 animate-shine"></div>
                </div>
            </div>
            <style>{`
                @keyframes wiggle {
                    0%, 100% { transform: translateX(-50%) rotate(-5deg); }
                    50% { transform: translateX(-50%) rotate(5deg); }
                }
                .animate-wiggle {
                    animation: wiggle 1s ease-in-out infinite;
                }
                @keyframes shine {
                    0% { left: -100%; }
                    100% { left: 200%; }
                }
                .animate-shine {
                    animation: shine 2s infinite;
                }
                @keyframes bounce-gentle {
                    0%, 100% { transform: translateY(0); }
                    50% { transform: translateY(-10px); }
                }
                .animate-bounce-gentle {
                    animation: bounce-gentle 2s ease-in-out infinite;
                }
            `}</style>
        </div>
    );
};

export default AchievementToast;

