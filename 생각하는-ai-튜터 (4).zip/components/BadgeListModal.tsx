
import React from 'react';
import { X, CheckCircle2 } from 'lucide-react';
import { BADGES } from '../constants';

interface BadgeListModalProps {
    isOpen: boolean;
    onClose: () => void;
    earnedBadges: string[];
}

const BadgeListModal: React.FC<BadgeListModalProps> = ({ isOpen, onClose, earnedBadges }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 transition-all duration-300">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg h-[70vh] flex flex-col overflow-hidden animate-scale-in">
                {/* Header */}
                <div className="bg-white p-5 sm:p-6 border-b border-gray-100 flex justify-between items-center flex-shrink-0">
                    <h2 className="text-xl sm:text-2xl font-bold text-gray-800 flex items-center gap-2">
                        <span className="text-yellow-500 text-2xl">🏆</span>
                        나의 배지 컬렉션
                    </h2>
                    <button 
                        onClick={onClose} 
                        className="text-gray-300 hover:text-gray-500 transition-colors p-2 hover:bg-gray-100 rounded-full"
                    >
                         <X className="w-6 h-6" />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-6 bg-gray-50/50 custom-scrollbar">
                    <div className="grid grid-cols-2 gap-4">
                        {BADGES.map((badge) => {
                            const isEarned = earnedBadges.includes(badge.id);
                            return (
                                <div 
                                    key={badge.id} 
                                    className={`relative flex flex-col items-center text-center p-4 rounded-2xl border transition-all duration-300 ${
                                        isEarned 
                                        ? 'bg-white border-yellow-200 shadow-md shadow-yellow-500/10 scale-100' 
                                        : 'bg-gray-100 border-gray-200 opacity-60 grayscale scale-95'
                                    }`}
                                >
                                    <div className={`text-4xl mb-3 ${isEarned ? 'animate-bounce-gentle' : ''}`}>
                                        {badge.icon}
                                    </div>
                                    <h3 className={`font-bold mb-1 ${isEarned ? 'text-gray-800' : 'text-gray-500'}`}>
                                        {badge.name}
                                    </h3>
                                    <p className="text-xs text-gray-500 break-keep leading-tight">
                                        {badge.description}
                                    </p>
                                    {!isEarned && (
                                        <div className="mt-3 text-[10px] font-bold text-gray-400 bg-gray-200 px-2 py-1 rounded-full">
                                            🔒 {badge.condition}
                                        </div>
                                    )}
                                    {isEarned && (
                                        <div className="absolute top-2 right-2 text-yellow-500">
                                            <CheckCircle2 className="w-5 h-5 fill-current" />
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* Footer */}
                <div className="p-5 sm:p-6 bg-white border-t border-gray-50">
                    <button 
                        onClick={onClose} 
                        className="w-full py-3.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl transition-colors"
                    >
                        닫기
                    </button>
                </div>
            </div>
        </div>
    );
};

export default BadgeListModal;
