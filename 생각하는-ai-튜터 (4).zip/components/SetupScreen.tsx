
import React, { useState, useCallback } from 'react';
import { Bot } from 'lucide-react';
import { AVATARS } from '../constants';
import type { StudentData, Avatar } from '../types';
import { StudentInfoForm } from './StudentInfoForm';

interface SetupScreenProps {
    onStart: (data: StudentData) => void;
}

const AvatarSelector: React.FC<{ selected: Avatar; onSelect: (avatar: Avatar) => void }> = ({ selected, onSelect }) => (
    <div className="flex justify-center flex-wrap gap-4 sm:gap-6 my-4 sm:my-6">
        {AVATARS.map((avatar) => {
            const isSelected = selected.name === avatar.name;
            return (
                <button
                    key={avatar.name}
                    onClick={() => onSelect(avatar)}
                    className={`w-16 h-16 sm:w-20 sm:h-20 rounded-3xl flex items-center justify-center text-3xl sm:text-4xl transition-all duration-300 transform ${
                        isSelected 
                        ? 'bg-white shadow-xl scale-110 ring-4 ring-purple-300 ring-offset-2 z-10' 
                        : 'bg-white/60 hover:bg-white hover:scale-105 shadow-sm hover:shadow-md'
                    }`}
                    aria-label={`${avatar.name} 아바타 선택`}
                >
                    <span className={`transition-transform duration-300 ${isSelected ? 'scale-110' : 'grayscale opacity-50 hover:grayscale-0 hover:opacity-100'}`}>
                        {avatar.emoji}
                    </span>
                </button>
            );
        })}
    </div>
);


const SetupScreen: React.FC<SetupScreenProps> = ({ onStart }) => {
    const [school, setSchool] = useState('');
    const [grade, setGrade] = useState('');
    const [studentClass, setStudentClass] = useState('');
    const [studentNumber, setStudentNumber] = useState('');
    const [selectedAvatar, setSelectedAvatar] = useState<Avatar>(AVATARS[0]);
    const [error, setError] = useState('');

    const handleStart = useCallback(() => {
        if (!school || !grade || !studentClass || !studentNumber) {
            setError('모든 정보를 입력해주세요! 🙏');
            return;
        }
        setError('');
        onStart({
            school,
            grade,
            class: studentClass,
            studentNumber,
            avatar: selectedAvatar,
            // 공백·특수문자 제거 → localStorage 키·Sheets 데이터 오염 방지
            sessionId: `${school}_${grade}_${studentClass}_${studentNumber}`
                .replace(/\s+/g, '').replace(/[^a-zA-Z0-9가-힣_]/g, '_'),
            xp: 0,
            level: 1,
            badges: []
        });
    }, [school, grade, studentClass, studentNumber, selectedAvatar, onStart]);

    return (
        <div className="w-full max-w-2xl bg-white/80 backdrop-blur-2xl rounded-3xl shadow-2xl p-6 sm:p-12 border border-white/50 ring-1 ring-black/5 animate-fade-in-up">
            <div className="text-center mb-6 sm:mb-8">
                <div className="w-16 h-16 sm:w-20 sm:h-20 mx-auto bg-gradient-to-tr from-purple-500 to-indigo-600 rounded-3xl flex items-center justify-center shadow-lg shadow-purple-500/30 rotate-3 transform hover:rotate-6 transition-transform duration-300 mb-4 sm:mb-6">
                    <Bot className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
                </div>
                <h1 className="text-2xl sm:text-4xl font-extrabold text-gray-900 tracking-tight mb-2">
                    생각하는 <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600">AI 챗봇</span>
                </h1>
                <p className="text-base sm:text-lg text-gray-500 font-medium">나만의 AI 튜터와 함께 대화해요!</p>
            </div>

            <div className="bg-gray-50/80 rounded-2xl p-4 sm:p-6 mb-6 sm:mb-8 border border-gray-100">
                <h3 className="text-center text-xs sm:text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">캐릭터 선택</h3>
                <AvatarSelector selected={selectedAvatar} onSelect={setSelectedAvatar} />
                
                <div className="relative bg-white rounded-xl p-5 sm:p-6 text-center shadow-sm border border-purple-200 mt-6 min-h-[100px] flex flex-col items-center justify-center">
                    <div className="absolute -top-3.5 left-1/2 transform -translate-x-1/2 bg-purple-400 text-white text-xs sm:text-sm font-bold px-4 py-1 rounded-full shadow-sm">
                        {selectedAvatar.name}
                    </div>
                    <p className="text-gray-600 text-sm sm:text-[15px] font-medium leading-relaxed break-keep mb-3">
                        "{selectedAvatar.description}"
                    </p>
                    <div className="w-full h-px bg-gray-100 mb-3" />
                    <div className="flex items-start gap-2 text-left w-full">
                        <div className="w-6 h-6 rounded-full bg-purple-50 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span className="text-xs">💬</span>
                        </div>
                        <p className="text-[11px] sm:text-xs text-purple-600/70 font-bold italic leading-tight">
                            {selectedAvatar.name === '픽셀' && "데이터 분석 완료! 🤖 시스템상으로는 이 주제가 가장 효율적이야!"}
                            {selectedAvatar.name === '토토' && "와아! 정말 신난다! 🐶✨ 우리 같이 재미있게 놀면서 배워볼까?"}
                            {selectedAvatar.name === '미라' && "지혜의 별이 반짝이는구나... 🧙‍♀️🔮 네 마음속에 어떤 호기심이 피어났니?"}
                            {selectedAvatar.name === '제트' && "미션 시작! 👨‍🚀🚀 새로운 디지털 행성을 탐험할 준비가 됐나, 대원?"}
                        </p>
                    </div>
                </div>
            </div>

            <div className="space-y-4 sm:space-y-6">
                <StudentInfoForm
                    school={school}
                    setSchool={setSchool}
                    grade={grade}
                    setGrade={setGrade}
                    studentClass={studentClass}
                    setStudentClass={setStudentClass}
                    studentNumber={studentNumber}
                    setStudentNumber={setStudentNumber}
                />

                {error && (
                    <div className="p-3 bg-red-50 text-red-600 text-xs sm:text-sm font-medium rounded-xl text-center border border-red-100 animate-shake">
                        {error}
                    </div>
                )}

                <button 
                    onClick={handleStart} 
                    className="w-full mt-2 sm:mt-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-base sm:text-lg font-bold py-3 sm:py-4 px-6 rounded-2xl shadow-lg shadow-purple-500/30 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 active:scale-95"
                >
                    대화 시작하기 ✨
                </button>
            </div>
        </div>
    );
};

export default SetupScreen;
