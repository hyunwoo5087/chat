import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Loader2 } from 'lucide-react';
import type { Message } from '../types';
import MessageBubble from './MessageBubble';

interface MessageListProps {
    messages: Message[];
    isLoading: boolean;
    avatarEmoji: string;
    avatarName: string;
}

const MessageList: React.FC<MessageListProps> = ({ messages, isLoading, avatarEmoji, avatarName }) => {
    const messagesEndRef = useRef<null | HTMLDivElement>(null);

    // [개선] 메시지 내용이 변할 때마다(스트리밍 중 포함) 스크롤
    const lastMessageContent = messages[messages.length - 1]?.content;
    
    useEffect(() => {
        if (messages.length > 0) {
            // requestAnimationFrame을 사용하여 DOM 업데이트 후 스크롤 보장
            requestAnimationFrame(() => {
                messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
            });
        }
    }, [messages.length, isLoading, lastMessageContent]);

    // [개선] 스트리밍 중(placeholder 버블이 이미 표시 중)에는 로딩 스피너 숨김
    // 마지막 메시지가 AI 응답이면 스트리밍 진행 중이므로 스피너 불필요
    const lastMsg = messages[messages.length - 1];
    const isStreaming = isLoading && lastMsg?.role === 'model';
    const showSpinner = isLoading && !isStreaming;

    return (
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 custom-scrollbar bg-gray-50/30">
            {messages.length === 0 && !isLoading && (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 animate-fade-in">
                    <div className="w-20 h-20 bg-white rounded-3xl shadow-sm flex items-center justify-center text-4xl mb-4 border border-gray-100">
                        {avatarEmoji}
                    </div>
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{avatarName}와 대화를 시작해보세요!</h3>
                    <p className="text-gray-500 max-w-xs break-keep">
                        궁금한 것을 물어보거나, 아래의 주제 추천 버튼을 눌러보세요.
                    </p>
                </div>
            )}

            {messages.map((message, index) => (
                <MessageBubble
                    key={`${(message as any)._streamId || message.timestamp}-${index}`}
                    message={message}
                    avatarEmoji={avatarEmoji}
                />
            ))}
            {showSpinner && (
                <div className="flex items-end gap-3 animate-fade-in">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center bg-white shadow-sm border border-gray-100 text-2xl flex-shrink-0">
                        {avatarEmoji}
                    </div>
                    <div className="max-w-md">
                        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl rounded-bl-md p-4 flex gap-1.5 items-center">
                            <motion.div
                                animate={{ scale: [1, 1.2, 1] }}
                                transition={{ repeat: Infinity, duration: 0.6, delay: 0 }}
                                className="w-1.5 h-1.5 bg-purple-400 rounded-full"
                            />
                            <motion.div
                                animate={{ scale: [1, 1.2, 1] }}
                                transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }}
                                className="w-1.5 h-1.5 bg-purple-400 rounded-full"
                            />
                            <motion.div
                                animate={{ scale: [1, 1.2, 1] }}
                                transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }}
                                className="w-1.5 h-1.5 bg-purple-400 rounded-full"
                            />
                        </div>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} className="h-4" />
        </div>
    );
};

export default MessageList;
