
import React from 'react';

interface StudentInfoFormProps {
    school: string;
    setSchool: (value: string) => void;
    grade: string;
    setGrade: (value: string) => void;
    studentClass: string;
    setStudentClass: (value: string) => void;
    studentNumber: string;
    setStudentNumber: (value: string) => void;
}

export const StudentInfoForm: React.FC<StudentInfoFormProps> = ({
    school, setSchool,
    grade, setGrade,
    studentClass, setStudentClass,
    studentNumber, setStudentNumber,
}) => {
    const labelClasses = "block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 ml-1";
    const inputClasses = "w-full px-5 py-4 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-purple-500/10 focus:border-purple-500 transition-all duration-300 text-slate-800 placeholder-slate-400 font-medium text-base shadow-sm hover:border-slate-300";
    const selectClasses = `${inputClasses} appearance-none cursor-pointer`;

    return (
        <div className="space-y-6">
            {/* 학교 이름 */}
            <div className="animate-fade-in" style={{ animationDelay: '0.1s' }}>
                <label className={labelClasses}>🏫 학교 이름</label>
                <input
                    type="text"
                    value={school}
                    onChange={(e) => setSchool(e.target.value)}
                    placeholder="학교 이름을 입력해주세요 (예: 서울초등학교)"
                    className={inputClasses}
                    aria-label="학교 이름 입력"
                />
            </div>

            {/* 학년 및 반 */}
            <div className="grid grid-cols-2 gap-4">
                <div className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
                    <label className={labelClasses}>🎒 학년</label>
                    <div className="relative">
                        <select
                            value={grade}
                            onChange={(e) => setGrade(e.target.value)}
                            className={selectClasses}
                            aria-label="학년 선택"
                        >
                            <option value="" disabled>학년 선택</option>
                            {[1, 2, 3, 4, 5, 6].map(g => (
                                <option key={g} value={`${g}학년`}>{g}학년</option>
                            ))}
                        </select>
                        <ChevronIcon />
                    </div>
                </div>

                <div className="animate-fade-in" style={{ animationDelay: '0.3s' }}>
                    <label className={labelClasses}>👥 반</label>
                    <div className="relative">
                        <select
                            value={studentClass}
                            onChange={(e) => setStudentClass(e.target.value)}
                            className={selectClasses}
                            aria-label="반 선택"
                        >
                            <option value="" disabled>반 선택</option>
                            {Array.from({ length: 10 }, (_, i) => i + 1).map(c => (
                                <option key={c} value={`${c}반`}>{c}반</option>
                            ))}
                        </select>
                        <ChevronIcon />
                    </div>
                </div>
            </div>

            {/* 번호 */}
            <div className="animate-fade-in" style={{ animationDelay: '0.4s' }}>
                <label className={labelClasses}>🔢 번호</label>
                <div className="relative">
                    <select
                        value={studentNumber}
                        onChange={(e) => setStudentNumber(e.target.value)}
                        className={selectClasses}
                        aria-label="번호 선택"
                    >
                        <option value="" disabled>번호 선택</option>
                        {Array.from({ length: 40 }, (_, i) => i + 1).map(n => (
                            <option key={n} value={`${n}번`}>{n}번</option>
                        ))}
                    </select>
                    <ChevronIcon />
                </div>
                <p className="mt-2 text-[10px] text-slate-400 font-medium ml-1">
                    * 번호는 학습 기록을 연결하는 데 사용됩니다.
                </p>
            </div>
        </div>
    );
};

const ChevronIcon = () => (
    <div className="absolute inset-y-0 right-5 flex items-center pointer-events-none text-slate-400">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
        </svg>
    </div>
);
