

import React, { useState, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrainCircuit, User, Sparkles, ChevronDown, CheckCircle2 } from 'lucide-react';
import type { Message } from '../types';

interface MessageBubbleProps {
    message: Message;
    avatarEmoji: string;
}

const DOK_LEVELS = {
    1: {
        label: "1단계",
        title: "기억하기 (사실 확인)",
        desc: "배운 내용을 기억하고 사실을 정확하게 말해요.",
        color: "blue", bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700", icon: "📝"
    },
    2: {
        label: "2단계",
        title: "비교하기 (차이점/패턴)",
        desc: "서로 비교하고 공통점과 차이점, 패턴을 찾아내요.",
        color: "emerald", bg: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-700", icon: "🔍"
    },
    3: {
        label: "3단계",
        title: "추론하기 (원인/이유)",
        desc: "왜 그런지 이유와 원인을 논리적인 근거로 설명해요.",
        color: "amber", bg: "bg-amber-50", border: "border-amber-200", text: "text-amber-700", icon: "💡"
    },
    4: {
        label: "4단계",
        title: "창조하기 (통합/해결)",
        desc: "지식을 연결하여 새로운 아이디어나 해결책을 만들어요.",
        color: "violet", bg: "bg-violet-50", border: "border-violet-200", text: "text-violet-700", icon: "🚀"
    },
};

const DokProgressBar: React.FC<{ questionLevel: number; answerLevel: number }> = ({ questionLevel, answerLevel }) => {
    const getBarColor = (l: number) => {
        if (l === 1) return "bg-blue-400";
        if (l === 2) return "bg-emerald-400";
        if (l === 3) return "bg-amber-400";
        if (l === 4) return "bg-violet-400";
        return "bg-slate-200";
    };

    return (
        <div className="w-full bg-slate-50/50 px-4 py-4 rounded-2xl border border-slate-100 space-y-3">
            {/* 답변 DOK — 핵심 측정값 (굵은 막대) */}
            <div className="flex items-center gap-4">
                <span className="text-[11px] font-bold text-slate-600 whitespace-nowrap w-16">내 생각 수준</span>
                <div className="flex-1 grid grid-cols-4 gap-2 h-2.5">
                    {[1, 2, 3, 4].map((l) => (
                        <div key={l} className="bg-slate-200 rounded-full h-full overflow-hidden">
                            <div
                                className={`h-full rounded-full transition-all duration-500 ${l <= answerLevel ? getBarColor(l) : 'opacity-0'}`}
                                style={{ width: l <= answerLevel ? '100%' : '0%' }}
                            />
                        </div>
                    ))}
                </div>
                <span className={`text-xs font-bold w-12 text-right ${
                    answerLevel === 4 ? 'text-violet-600' :
                    answerLevel === 3 ? 'text-amber-600' :
                    answerLevel === 2 ? 'text-emerald-600' : 'text-blue-600'
                }`}>{answerLevel}단계</span>
            </div>
            {/* 질문 DOK — 참고값 (흐린 얇은 막대) */}
            <div className="flex items-center gap-4 opacity-50">
                <span className="text-[11px] text-slate-400 whitespace-nowrap w-16">질문 수준</span>
                <div className="flex-1 grid grid-cols-4 gap-2 h-1.5">
                    {[1, 2, 3, 4].map((l) => (
                        <div key={l} className="bg-slate-100 rounded-full h-full overflow-hidden">
                            <div
                                className={`h-full rounded-full transition-all duration-500 ${l <= questionLevel ? 'bg-slate-400' : 'opacity-0'}`}
                                style={{ width: l <= questionLevel ? '100%' : '0%' }}
                            />
                        </div>
                    ))}
                </div>
                <span className="text-[11px] text-slate-400 w-12 text-right">{questionLevel}단계</span>
            </div>
        </div>
    );
};

const formatContent = (text: string): React.ReactNode => {
    const renderSegmentWithFormatting = (segment: string) => {
        const parts = segment.split(/(\*\*.*?\*\*)/g);
        return parts.map((part, i) => {
            if (part.startsWith('**') && part.endsWith('**')) {
                return <strong key={i} className="font-bold text-indigo-700 bg-indigo-50 px-1 rounded mx-0.5">{part.slice(2, -2)}</strong>;
            }
            return part;
        });
    };

    const lines = text.split('\n');
    const elements: React.ReactNode[] = [];
    let currentList: { type: 'ul' | 'ol'; items: string[] } | null = null;

    const flushList = () => {
        if (currentList) {
            const ListComponent = currentList.type;
            elements.push(
                <ListComponent key={`list-${elements.length}`} className={`${ListComponent === 'ul' ? 'list-disc' : 'list-decimal'} list-outside pl-6 my-4 space-y-2 text-slate-700`}>
                    {currentList.items.map((item, index) => (
                        <li key={index} className="pl-1 leading-relaxed break-keep">{renderSegmentWithFormatting(item)}</li>
                    ))}
                </ListComponent>
            );
            currentList = null;
        }
    };

    lines.forEach((line, index) => {
        const trimmedLine = line.trim();
        if (trimmedLine === '') {
            if (!currentList) elements.push(<div key={`spacer-${index}`} className="h-2" />); 
            return;
        }

        const isUnordered = trimmedLine.startsWith('- ');
        const isOrdered = !!trimmedLine.match(/^\d+\.\s/);

        if (isUnordered || isOrdered) {
            const type = isUnordered ? 'ul' : 'ol';
            const content = isUnordered ? trimmedLine.substring(2) : trimmedLine.replace(/^\d+\.\s/, '');
            if (currentList && currentList.type !== type) flushList();
            if (!currentList) currentList = { type, items: [] };
            currentList.items.push(content);
        } else {
            flushList();
            elements.push(<p key={`p-${index}`} className="mb-3 leading-relaxed text-slate-800 break-keep">{renderSegmentWithFormatting(line)}</p>);
        }
    });

    flushList();
    return elements;
};

const ContentRenderer: React.FC<{ content: string; isStreaming?: boolean }> = memo(({ content, isStreaming }) => {
    const summaryBoxRegex = /<div class="summary-box">([\s\S]*?)<\/div>/;
    const match = content.match(summaryBoxRegex);

    let mainText = content;
    let summaryHtml: string | null = null;
    let questionText: string | null = null;

    if (match && match.index !== undefined) {
        mainText = content.substring(0, match.index).trim();
        summaryHtml = match[1].trim();
        questionText = content.substring(match.index + match[0].length).trim();
    }

    return (
        <div className="text-[15px] sm:text-[16px]">
            <div className="space-y-1 mb-4">
                {formatContent(mainText)}
                {isStreaming && !summaryHtml && !questionText && (
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 0.8 }} className="inline-block w-1.5 h-5 ml-1 bg-indigo-400 align-middle" />
                )}
            </div>

            {summaryHtml && (
                <motion.div 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="my-6 bg-indigo-50/50 border-l-4 border-indigo-500 p-5 rounded-r-2xl shadow-sm"
                >
                    <div 
                        className="text-slate-800 text-sm leading-relaxed [&>strong]:text-indigo-700 [&>strong]:block [&>strong]:mb-1 [&>strong]:text-base break-keep"
                        dangerouslySetInnerHTML={{ __html: summaryHtml }} 
                    />
                </motion.div>
            )}

            {questionText && (
                <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-10 relative"
                >
                    <div className="absolute -top-3.5 left-6 bg-white px-4 py-1 border border-indigo-100 rounded-full flex items-center gap-2 shadow-sm z-10">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                        <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">Next Step</span>
                    </div>
                    
                    <div className="bg-white border border-indigo-100 rounded-3xl p-6 pt-8 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.08)] transition-shadow duration-500">
                         <div className="font-semibold text-lg leading-relaxed text-slate-900 break-keep">
                            {formatContent(questionText)}
                            {isStreaming && (
                                <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 0.8 }} className="inline-block w-1.5 h-5 ml-1 bg-indigo-400 align-middle" />
                            )}
                         </div>
                         <div className="mt-4 flex items-center justify-end">
                             <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-3 py-1.5 rounded-full flex items-center gap-1.5">
                                 <CheckCircle2 className="w-3 h-3" />
                                 답변을 입력해서 대화를 이어가세요
                             </span>
                         </div>
                    </div>
                </motion.div>
            )}
        </div>
    );
});


const MessageBubble: React.FC<MessageBubbleProps> = ({ message, avatarEmoji }) => {
    const isUser = message.role === 'user';
    const [isAnalysisVisible, setIsAnalysisVisible] = useState(false);
    const isStreaming = !!(message as any)._streamId;

    if (isUser) {
        return (
            <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-end gap-3 justify-end mb-6"
            >
                <div className="order-1 text-right max-w-[85%] sm:max-w-[70%]">
                    <div className="bg-indigo-600 text-white rounded-[2rem] rounded-tr-sm p-4 sm:p-6 shadow-xl shadow-indigo-100 text-left">
                        <p className="text-[15px] sm:text-[16px] leading-relaxed break-words whitespace-pre-wrap font-medium">{message.content}</p>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-2 font-bold uppercase tracking-tighter mr-2">{message.timestamp}</p>
                </div>
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center bg-white border border-slate-100 shadow-sm flex-shrink-0 order-2">
                    <User className="w-5 h-5 sm:w-6 sm:h-6 text-slate-400" />
                </div>
            </motion.div>
        );
    }

    const hasAnalysis = message.analysisData && message.analysisData.keris_sub !== "분석 없음";
    const currentLevel = message.analysisData?.dok_level || 0;

    return (
        <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-start gap-4 w-full mb-8"
        >
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-[1.25rem] flex items-center justify-center bg-white border border-slate-100 text-2xl shadow-sm flex-shrink-0 mt-1">
                {avatarEmoji}
            </div>
            
            <div className="max-w-[95%] sm:max-w-[85%] flex-1 space-y-4">
                <div className="bg-white rounded-[2rem] rounded-tl-sm p-6 sm:p-8 shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-slate-50 relative">
                    <ContentRenderer content={message.content} isStreaming={isStreaming} />
                </div>

                <div className="pl-4">
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">{message.timestamp}</p>
                </div>

                {hasAnalysis && (
                    <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
                        <div className="p-5 flex flex-col gap-4">
                             <DokProgressBar questionLevel={message.analysisData?.question_dok_level || currentLevel} answerLevel={message.analysisData?.answer_dok_level || currentLevel} />
                             
                             <button
                                onClick={() => setIsAnalysisVisible(!isAnalysisVisible)}
                                className="flex items-center justify-between w-full p-4 rounded-2xl bg-slate-50 hover:bg-slate-100 transition-colors group"
                            >
                                <div className="flex items-center gap-3">
                                    <div className="bg-white p-2 rounded-xl shadow-sm border border-slate-100 text-slate-400 group-hover:text-indigo-600 transition-colors">
                                        <BrainCircuit className="w-4 h-4" />
                                    </div>
                                    <span className="text-sm font-bold text-slate-600">AI 사고 분석 리포트</span>
                                </div>
                                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 ${isAnalysisVisible ? 'rotate-180' : ''}`} />
                            </button>
                        </div>

                        <AnimatePresence>
                            {isAnalysisVisible && (
                                <motion.div 
                                    initial={{ height: 0, opacity: 0 }}
                                    animate={{ height: 'auto', opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                    className="overflow-hidden"
                                >
                                    <div className="px-5 pb-6 space-y-6">
                                        <div className="grid sm:grid-cols-2 gap-4">
                                            <div className="bg-indigo-50/70 rounded-2xl p-5 border border-indigo-100 shadow-sm relative overflow-hidden group">
                                                <div className="absolute top-0 right-0 p-3 opacity-5 group-hover:scale-110 transition-transform">
                                                    <Sparkles className="w-12 h-12 text-indigo-500" />
                                                </div>
                                                <div className="relative z-10">
                                                    <div className="flex items-center gap-2 mb-3">
                                                        <div className="w-6 h-6 bg-white rounded-lg flex items-center justify-center shadow-sm">
                                                            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                                                        </div>
                                                        <span className="text-[11px] font-bold text-indigo-700 uppercase tracking-widest">분석 근거</span>
                                                    </div>
                                                    <p className="text-sm text-slate-700 leading-relaxed font-medium break-keep">
                                                        {message.analysisData!.dok_reasoning}
                                                    </p>
                                                </div>
                                            </div>
                                            {message.analysisData!.answer_quality_feedback && message.analysisData!.answer_quality_feedback !== "분석 없음" && (
                                                <div className="bg-emerald-50/70 rounded-2xl p-5 border border-emerald-100 shadow-sm relative overflow-hidden group">
                                                    <div className="absolute top-0 right-0 p-3 opacity-5 group-hover:scale-110 transition-transform">
                                                        <CheckCircle2 className="w-12 h-12 text-emerald-500" />
                                                    </div>
                                                    <div className="relative z-10">
                                                        <div className="flex items-center gap-2 mb-3">
                                                            <div className="w-6 h-6 bg-white rounded-lg flex items-center justify-center shadow-sm">
                                                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                                                            </div>
                                                            <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-widest">학습 가이드</span>
                                                        </div>
                                                        <p className="text-sm text-slate-700 leading-relaxed font-medium break-keep">
                                                            {message.analysisData!.answer_quality_feedback}
                                                        </p>
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        <div className="space-y-3">
                                            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest px-1">DOK Level Guide</span>
                                            <div className="grid gap-2">
                                                {[1, 2, 3, 4].map((lvl) => {
                                                    const isActive = lvl === currentLevel;
                                                    // @ts-ignore
                                                    const style = DOK_LEVELS[lvl];
                                                    return (
                                                        <div 
                                                            key={lvl} 
                                                            className={`flex items-center gap-4 p-4 rounded-2xl border transition-all duration-300 ${
                                                                isActive 
                                                                ? `${style.bg} ${style.border} shadow-sm scale-[1.02]` 
                                                                : 'bg-white border-slate-50 text-slate-400 opacity-40'
                                                            }`}
                                                        >
                                                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl shadow-sm ${isActive ? 'bg-white' : 'bg-slate-50 grayscale'}`}>
                                                                {style.icon}
                                                            </div>
                                                            <div className="flex-1 min-w-0">
                                                                <div className="flex items-center gap-2">
                                                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${isActive ? 'bg-white/60 text-slate-800' : 'bg-slate-100 text-slate-400'}`}>{style.label}</span>
                                                                    <span className={`text-sm font-bold truncate ${isActive ? style.text : 'text-slate-400'}`}>{style.title}</span>
                                                                </div>
                                                                {isActive && (
                                                                    <p className="text-[11px] mt-1 text-slate-600 leading-relaxed">{style.desc}</p>
                                                                )}
                                                            </div>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>
                )}
            </div>
        </motion.div>
    );
};

export default memo(MessageBubble);
