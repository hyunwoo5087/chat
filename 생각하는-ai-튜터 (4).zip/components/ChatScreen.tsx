

import React, { useState, useEffect, useRef } from 'react';
import type { StudentData } from '../types';
import { useChat } from '../hooks/useChat';
import ChatHeader from './ChatHeader';
import MessageList from './MessageList';
import ChatInput from './ChatInput';
import JournalModal from './JournalModal';
import JournalHistoryModal from './JournalHistoryModal';
import BadgeListModal from './BadgeListModal';
import AchievementToast, { AchievementType } from './AchievementToast';
import SessionSummaryModal from './SessionSummaryModal';
import LevelUpModal from './LevelUpModal';
import confetti from 'canvas-confetti';
import { BADGES, LEVEL_THRESHOLDS, LEVEL_META } from '../constants';

interface ChatScreenProps {
    studentData: StudentData;
    onReset: () => void;
}

interface ToastState {
    type: AchievementType;
    data: any;
}

const ChatScreen: React.FC<ChatScreenProps> = ({ studentData: initialStudentData, onReset }) => {
    // 내부 상태로 StudentData 관리 (XP 업데이트 반영)
    // [추가] localStorage에서 XP·레벨·배지 복원 (세션 간 영구 저장)
    const PROGRESS_KEY = `progress_${initialStudentData.sessionId}`;
    const loadSavedProgress = (): Pick<StudentData, 'xp' | 'level' | 'badges'> => {
        try {
            const saved = localStorage.getItem(PROGRESS_KEY);
            if (saved) return JSON.parse(saved);
        } catch { /* 손상된 데이터 무시 */ }
        return { xp: 0, level: 1, badges: [] };
    };
    const [currentStudentData, setCurrentStudentData] = useState<StudentData>({
        ...initialStudentData,
        ...loadSavedProgress(),
    });
    const { messages, isLoading, journals, sendMessage, requestHint, handleTopicRoulette, saveJournal } = useChat(currentStudentData);
    
    const [isJournalOpen, setIsJournalOpen] = useState(false);
    const [isHistoryOpen, setIsHistoryOpen] = useState(false);
    const [isBadgeOpen, setIsBadgeOpen] = useState(false);
    const [isSummaryOpen, setIsSummaryOpen] = useState(false); // [추가] 세션 요약 모달
    const [isLevelUpOpen, setIsLevelUpOpen] = useState(false);
    const [lastLevelUp, setLastLevelUp] = useState(1);
    
    const [toast, setToast] = useState<ToastState | null>(null);
    
    // 마지막으로 처리한 메시지 및 일기 개수를 추적하여 중복 XP/배지 방지
    const processedMessagesCount = useRef(0);
    const processedJournalsCount = useRef(0);

    // [개선] 일기 메시지 제외 - 실제 대화 메시지만 카운트
    const userMessages = messages.filter(m => m.role === 'user' && !(m as any).isJournal);
    const userHasSentMessage = userMessages.length > 0;
    // [추가] 힌트: AI가 소크라테스 질문을 1회 이상 던진 이후 활성화
    const aiHasSentQuestion = messages.filter(m => m.role === 'model' && m.analysisData).length > 0;

    // --- XP & Badge Logic ---
    useEffect(() => {
        if (messages.length === processedMessagesCount.current && journals.length === processedJournalsCount.current) {
            return;
        }

        let newXp = currentStudentData.xp;
        let newBadges = [...currentStudentData.badges];
        let toastQueue: ToastState[] = [];

        // 1. Process New Messages
        if (messages.length > processedMessagesCount.current) {
            const newMsgs = messages.slice(processedMessagesCount.current);
            newMsgs.forEach(msg => {
                if (msg.role === 'model' && msg.analysisData) {
                    const answerDok = msg.analysisData.answer_dok_level || msg.analysisData.dok_level;

                    // [XP 재설계] 메시지 수 XP 제거 — DOK 수준 중심으로 재배분
                    if (answerDok === 2) newXp += 15;
                    if (answerDok === 3) newXp += 40;
                    if (answerDok === 4) newXp += 70;

                    // [힌트 없이 고DOK] 보너스 XP
                    const prevMsg = messages[messages.indexOf(msg) - 1];
                    const hintNotUsed = prevMsg && !(prevMsg as any).isHint;
                    if (hintNotUsed && answerDok === 3) newXp += 15;
                    if (hintNotUsed && answerDok === 4) newXp += 25;

                    // DOK Toast (2단계 이상 모두 피드백)
                    if (answerDok >= 2) {
                        toastQueue.push({ type: 'dok', data: { level: answerDok } });
                    }
                }
            });
            processedMessagesCount.current = messages.length;
        }

        // 2. Process New Journals
        if (journals.length > processedJournalsCount.current) {
            const newJournalCount = journals.length - processedJournalsCount.current;
            newXp += 25 * newJournalCount;
            processedJournalsCount.current = journals.length;
        }

        // 3. Level Up Check
        let newLevel = currentStudentData.level;
        while (newLevel < LEVEL_THRESHOLDS.length - 1) {
            const nextThreshold = LEVEL_THRESHOLDS[newLevel] || Infinity;
            if (newXp >= nextThreshold) {
                newLevel++;
                setLastLevelUp(newLevel);
                setIsLevelUpOpen(true);
                triggerConfetti(5);
            } else {
                break;
            }
        }

        // 4. Badge Check
        const userMsgCount = messages.filter(m => m.role === 'user' && !(m as any).isJournal).length;
        const journalCount = journals.length;
        const allModelMsgs = messages.filter(m => m.role === 'model' && m.analysisData);

        const checkAndAddBadge = (id: string) => {
            if (!newBadges.includes(id)) {
                newBadges.push(id);
                const badgeInfo = BADGES.find(b => b.id === id);
                if (badgeInfo) {
                    toastQueue.push({ type: 'badge', data: { badgeName: badgeInfo.name, badgeIcon: badgeInfo.icon } });
                    triggerConfetti(4);
                }
            }
        };

        // 첫 발걸음
        if (userMsgCount >= 1)  checkAndAddBadge('first_chat');
        if (userMsgCount >= 5)  checkAndAddBadge('curious_5');
        if (userMsgCount >= 20) checkAndAddBadge('curious_20');

        // DOK 수준 배지
        const hasDok2 = allModelMsgs.some(m => (m.analysisData?.answer_dok_level ?? 0) >= 2);
        const hasDok3 = allModelMsgs.some(m => (m.analysisData?.answer_dok_level ?? 0) >= 3);
        const hasDok4 = allModelMsgs.some(m => (m.analysisData?.answer_dok_level ?? 0) >= 4);
        if (hasDok2) checkAndAddBadge('dok2_first');
        if (hasDok3) checkAndAddBadge('logic_detective');
        if (hasDok4) checkAndAddBadge('creative_wizard');

        // DOK 3 연속 3회
        let streak = 0;
        let maxStreak = 0;
        allModelMsgs.forEach(m => {
            if ((m.analysisData?.answer_dok_level ?? 0) >= 3) { streak++; maxStreak = Math.max(maxStreak, streak); }
            else streak = 0;
        });
        if (maxStreak >= 3) checkAndAddBadge('dok3_streak');

        // 힌트 없이 DOK 3/4
        const noHintDok3 = allModelMsgs.some((m, i) => {
            const prev = messages[messages.indexOf(m) - 1];
            return (m.analysisData?.answer_dok_level ?? 0) >= 3 && !(prev as any)?.isHint;
        });
        const noHintDok4 = allModelMsgs.some((m) => {
            const prev = messages[messages.indexOf(m) - 1];
            return (m.analysisData?.answer_dok_level ?? 0) >= 4 && !(prev as any)?.isHint;
        });
        if (noHintDok3) checkAndAddBadge('no_hint_dok3');
        if (noHintDok4) checkAndAddBadge('no_hint_dok4');

        // KERIS 영역 배지
        const kerisAreas = new Set(allModelMsgs.map(m => m.analysisData?.keris_major).filter(Boolean));
        if ([...kerisAreas].some(a => a?.includes('기기')))  checkAndAddBadge('keris_device');
        if ([...kerisAreas].some(a => a?.includes('정보')))  checkAndAddBadge('keris_info');
        if ([...kerisAreas].some(a => a?.includes('소통')))  checkAndAddBadge('keris_comm');
        if ([...kerisAreas].some(a => a?.includes('윤리')))  checkAndAddBadge('keris_ethics');
        const kerisIds = ['keris_device','keris_info','keris_comm','keris_ethics'];
        if (kerisIds.every(id => newBadges.includes(id))) checkAndAddBadge('keris_all');

        // 꾸준함 배지
        if (journalCount >= 1) checkAndAddBadge('journal_first');
        if (journalCount >= 3) checkAndAddBadge('journal_3');
        if (journalCount >= 5) checkAndAddBadge('journal_5');

        // 레벨 도달 배지
        if (newLevel >= 3) checkAndAddBadge('level_3');
        if (newLevel >= 6) checkAndAddBadge('level_6');

        // 상태 저장
        if (newXp !== currentStudentData.xp || newBadges.length !== currentStudentData.badges.length || newLevel !== currentStudentData.level) {
            const progress = { xp: newXp, level: newLevel, badges: newBadges };
            try { localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress)); } catch { /* 저장 실패 무시 */ }
            setCurrentStudentData(prev => ({ ...prev, ...progress }));
        }

        if (toastQueue.length > 0) {
            const priority = (type: AchievementType) => {
                if (type === 'levelup') return 3;
                if (type === 'badge')   return 2;
                return 1;
            };
            toastQueue.sort((a, b) => priority(b.type) - priority(a.type));
            setToast(toastQueue[0]);
        }

    }, [messages, journals, currentStudentData]);

    const triggerConfetti = (intensity: number) => {
        const duration = 2000;
        const end = Date.now() + duration;
        const colors = intensity === 5 
            ? ['#FFD700', '#FFA500', '#FFFFFF'] // Gold for Level Up/Badge
            : ['#a855f7', '#d946ef', '#ec4899']; 

        (function frame() {
            confetti({
                particleCount: intensity === 5 ? 7 : 3,
                angle: 60,
                spread: 55,
                origin: { x: 0 },
                colors: colors
            });
            confetti({
                particleCount: intensity === 5 ? 7 : 3,
                angle: 120,
                spread: 55,
                origin: { x: 1 },
                colors: colors
            });

            if (Date.now() < end) {
                requestAnimationFrame(frame);
            }
        }());
    };

    const handleSaveJournal = (learned: string, pledge: string) => {
        saveJournal(learned, pledge);
        // Basic confetti handled in useChat or here? Adding a small one here for immediate feedback
        confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.7 }
        });
    };

    return (
        <>
            <div className="w-full max-w-4xl mx-auto h-full bg-white/80 backdrop-blur-xl sm:rounded-3xl rounded-none shadow-2xl flex flex-col overflow-hidden border-x-0 sm:border border-white/50 ring-1 ring-black/5">
                <ChatHeader 
                    onReset={() => setIsSummaryOpen(true)} 
                    studentData={currentStudentData} 
                    onJournalHistoryClick={() => setIsHistoryOpen(true)}
                    onBadgeClick={() => setIsBadgeOpen(true)}
                />
                <MessageList 
                    messages={messages} 
                    isLoading={isLoading} 
                    avatarEmoji={currentStudentData.avatar.emoji} 
                    avatarName={currentStudentData.avatar.name} 
                />
                <ChatInput
                    onSendMessage={sendMessage}
                    onJournalClick={() => setIsJournalOpen(true)}
                    onRouletteClick={handleTopicRoulette}
                    onHintClick={requestHint}
                    isLoading={isLoading}
                    isJournalEnabled={userHasSentMessage}
                    isHintEnabled={aiHasSentQuestion}
                    studentData={currentStudentData}
                />
            </div>
            
            <JournalModal
                isOpen={isJournalOpen}
                onClose={() => setIsJournalOpen(false)}
                onSave={handleSaveJournal}
            />
            
            <JournalHistoryModal
                isOpen={isHistoryOpen}
                onClose={() => setIsHistoryOpen(false)}
                journals={journals}
            />

            <BadgeListModal 
                isOpen={isBadgeOpen}
                onClose={() => setIsBadgeOpen(false)}
                earnedBadges={currentStudentData.badges}
            />

            {/* [추가] 세션 종료 요약 모달 */}
            <SessionSummaryModal
                isOpen={isSummaryOpen}
                studentData={currentStudentData}
                messages={messages}
                onCancel={() => setIsSummaryOpen(false)}
                onConfirm={onReset}
            />

            <LevelUpModal 
                isOpen={isLevelUpOpen}
                level={lastLevelUp}
                onClose={() => setIsLevelUpOpen(false)}
            />

            {toast && (
                <AchievementToast 
                    type={toast.type} 
                    data={toast.data}
                    onClose={() => setToast(null)} 
                />
            )}
        </>
    );
};

export default ChatScreen;
