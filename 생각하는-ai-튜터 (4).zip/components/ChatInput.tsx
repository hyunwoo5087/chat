
import React, { useState } from 'react';
import { Send, BookOpen, Lightbulb, HelpCircle } from 'lucide-react';
import type { StudentData } from '../types';

interface ChatInputProps {
    onSendMessage: (message: string) => void;
    onJournalClick: () => void;
    onRouletteClick: () => void;
    onHintClick: () => void;      // [추가] 힌트 요청
    isLoading: boolean;
    isJournalEnabled: boolean;
    isHintEnabled: boolean;       // [추가] 첫 AI 응답 이후 활성화
    studentData: StudentData;
}

const ChatInput: React.FC<ChatInputProps> = ({ 
    onSendMessage, 
    onJournalClick, 
    onRouletteClick,
    onHintClick,
    isLoading, 
    isJournalEnabled,
    isHintEnabled,
    studentData 
}) => {
    const [inputValue, setInputValue] = useState('');

    const handleSend = () => {
        if (inputValue.trim() && !isLoading) {
            onSendMessage(inputValue);
            setInputValue('');
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    };

    const ActionButton: React.FC<{ onClick: () => void; title: string; disabled?: boolean; colorClass: string; children: React.ReactNode; }> = ({ onClick, title, disabled, colorClass, children }) => (
        <button
            onClick={onClick}
            title={title}
            disabled={disabled}
            // 모바일에서 터치하기 쉽도록 크기 증가 (w-11, h-11)
            className={`w-11 h-11 sm:w-12 sm:h-12 flex-shrink-0 flex items-center justify-center rounded-2xl transition-all duration-200 ${
                disabled 
                ? 'bg-gray-100 text-gray-300 cursor-not-allowed' 
                : `bg-white text-gray-600 shadow-sm border border-gray-100 hover:shadow-md hover:-translate-y-0.5 active:bg-gray-50 ${colorClass}`
            }`}
        >
            {children}
        </button>
    );

    return (
        <div className="p-3 sm:p-5 pb-[calc(0.75rem_+_env(safe-area-inset-bottom,0px))] sm:pb-[calc(1.25rem_+_env(safe-area-inset-bottom,0px))] bg-white/80 backdrop-blur-md border-t border-gray-100 flex items-center gap-2 sm:gap-3">
            <ActionButton 
                onClick={onJournalClick} 
                title="학습 일기 쓰기" 
                disabled={isLoading || !isJournalEnabled}
                colorClass="hover:text-pink-500 hover:border-pink-200"
            >
                <BookOpen className="w-5 h-5 sm:w-6 sm:h-6" />
            </ActionButton>
            
            <ActionButton 
                onClick={onRouletteClick} 
                title="주제 추천받기" 
                disabled={isLoading}
                colorClass="hover:text-yellow-500 hover:border-yellow-200"
            >
                <Lightbulb className="w-5 h-5 sm:w-6 sm:h-6" />
            </ActionButton>

            {/* [추가] 힌트 버튼 - AI가 질문한 뒤 학생이 막힐 때 사용 */}
            <ActionButton 
                onClick={onHintClick} 
                title="힌트 받기" 
                disabled={isLoading || !isHintEnabled}
                colorClass={`hover:text-emerald-500 hover:border-emerald-200 ${isHintEnabled && !isLoading ? 'animate-pulse-subtle text-emerald-600 border-emerald-100 bg-emerald-50' : ''}`}
            >
                <HelpCircle className="w-5 h-5 sm:w-6 sm:h-6" />
            </ActionButton>

            <div className="flex-1 relative group">
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder={isLoading ? "답변을 생각하는 중..." : "내용을 입력하세요..."}
                    disabled={isLoading}
                    // 모바일(기본)에서는 text-base(16px)를 사용하여 iOS 자동 줌 방지, 큰 화면에서는 text-base 유지
                    className="w-full h-11 sm:h-12 pl-4 sm:pl-6 pr-12 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 focus:bg-white transition-all duration-200 text-base placeholder-gray-400 shadow-inner appearance-none"
                    // 모바일 키보드 '이동' 버튼 활성화
                    enterKeyHint="send" 
                />
                <button
                    onClick={handleSend}
                    disabled={isLoading || !inputValue.trim()}
                    className={`absolute right-1 top-1/2 -translate-y-1/2 w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl transition-all duration-200 ${
                        isLoading || !inputValue.trim()
                        ? 'bg-gray-200 text-white cursor-not-allowed'
                        : 'bg-gradient-to-tr from-purple-600 to-indigo-600 text-white shadow-md hover:shadow-lg hover:scale-105 active:scale-95'
                    }`}
                >
                    <Send className="w-4 h-4 sm:w-5 sm:h-5" />
                </button>
            </div>
        </div>
    );
};

export default ChatInput;
